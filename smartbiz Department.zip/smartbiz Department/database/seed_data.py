import os
import json
from datetime import datetime, timedelta, timezone
from models.models import (
    db, User, Department, SubDepartment, Invoice, ExpenseClaim,
    Lead, ContractProposal, JobDescription, Resume, EmployeeDocument,
    SupportTicket, FAQArticle, HITLReview, ActivityLog, Notification, SystemSetting
)
from config import Config

def seed_demo_database():
    """Populates the database with realistic hackathon demo data with complete department isolation."""
    # Ensure tables exist
    db.create_all()

    # Clear existing data for fresh demo reload
    db.session.query(Notification).delete()
    db.session.query(ActivityLog).delete()
    db.session.query(HITLReview).delete()
    db.session.query(FAQArticle).delete()
    db.session.query(SupportTicket).delete()
    db.session.query(EmployeeDocument).delete()
    db.session.query(Resume).delete()
    db.session.query(JobDescription).delete()
    db.session.query(ContractProposal).delete()
    db.session.query(Lead).delete()
    db.session.query(ExpenseClaim).delete()
    db.session.query(Invoice).delete()
    db.session.query(User).delete()
    db.session.query(SubDepartment).delete()
    db.session.query(Department).delete()
    db.session.query(SystemSetting).delete()
    db.session.commit()

    # 1. System Settings
    db.session.add(SystemSetting(key='AUTO_PROCESS_THRESHOLD', value='80', description='Confidence threshold to auto-process without human review'))
    db.session.add(SystemSetting(key='HITL_REVIEW_THRESHOLD', value='60', description='Confidence threshold requiring mandatory HITL verification'))

    # 2. Departments
    dept_fin = Department(
        name='Finance & Accounting',
        code='FINANCE',
        description='Financial accounting, invoice audit, payments, and payroll expense management.',
        icon='bi-cash-stack',
        color='success'
    )
    dept_hr = Department(
        name='Human Resources (HR)',
        code='HR',
        description='Talent acquisition, candidate screening, onboarding, and HR compliance.',
        icon='bi-people',
        color='info'
    )
    dept_sales = Department(
        name='Sales & Business Development',
        code='SALES',
        description='Inbound lead qualification, intent classification, CRM auto-ingestion, and contracts.',
        icon='bi-graph-up-arrow',
        color='primary'
    )
    dept_support = Department(
        name='Customer Support & Service',
        code='SUPPORT',
        description='Support ticket triage, automated NLP classification, routing, and AI responses.',
        icon='bi-headset',
        color='warning'
    )
    dept_comp = Department(
        name='Operations & Compliance',
        code='COMPLIANCE',
        description='Audit governance, human-in-the-loop review orchestration, and regulatory compliance.',
        icon='bi-shield-check',
        color='danger'
    )
    db.session.add_all([dept_fin, dept_hr, dept_sales, dept_support, dept_comp])
    db.session.commit()

    # 3. Sub-Departments
    # Finance Sub-departments
    sd_ap = SubDepartment(department_id=dept_fin.id, name='Accounts Payable', code='accounts_payable', description='Invoice processing, vendor matching, tax/VAT validation')
    sd_pe = SubDepartment(department_id=dept_fin.id, name='Payroll & Expenses', code='payroll_expenses', description='Employee expense claims, reimbursement routing')

    # HR Sub-departments
    sd_ta = SubDepartment(department_id=dept_hr.id, name='Talent Acquisition', code='talent_acquisition', description='Resume screening, candidate ranking, interview scheduling')
    sd_oo = SubDepartment(department_id=dept_hr.id, name='Onboarding & Offboarding', code='onboarding_offboarding', description='Employee document processing, compliance verification')

    # Sales Sub-departments
    sd_lm = SubDepartment(department_id=dept_sales.id, name='Lead Management', code='lead_management', description='Inbound lead scoring, intent classification, CRM auto-ingestion')
    sd_co = SubDepartment(department_id=dept_sales.id, name='Contract Operations', code='contract_operations', description='Proposal parsing, contract data extraction')

    # Support Sub-departments
    sd_to = SubDepartment(department_id=dept_support.id, name='Ticket Operations', code='ticket_operations', description='All support tickets, priority, sentiment, department routing')
    sd_ra = SubDepartment(department_id=dept_support.id, name='Response Automation', code='response_automation', description='AI auto-replies, FAQ knowledge-base matching')

    # Compliance Sub-departments
    sd_ag = SubDepartment(department_id=dept_comp.id, name='Audit & Governance', code='audit_governance', description='Human-in-the-Loop review queue, confidence thresholds, audit logging')

    db.session.add_all([sd_ap, sd_pe, sd_ta, sd_oo, sd_lm, sd_co, sd_to, sd_ra, sd_ag])
    db.session.commit()

    # 4. Users (Official Test Accounts as per Master Prompt)
    users_data = [
        # (Name, email, password, role, dept_id, sub_dept_id)
        ('Alex Morgan', 'admin@smartbiz.local', 'smartbiz123', 'ADMIN', None, None),
        ('Sarah Jenkins', 'finance@smartbiz.local', 'smartbiz123', 'FINANCE', dept_fin.id, sd_ap.id),
        ('Rachel Green', 'hr@smartbiz.local', 'smartbiz123', 'HR', dept_hr.id, sd_ta.id),
        ('David Ross', 'sales@smartbiz.local', 'smartbiz123', 'SALES', dept_sales.id, sd_lm.id),
        ('Michael Chang', 'support@smartbiz.local', 'smartbiz123', 'SUPPORT', dept_support.id, sd_to.id),
        ('Elena Vance', 'compliance@smartbiz.local', 'smartbiz123', 'COMPLIANCE', dept_comp.id, sd_ag.id),
        
        # Compatibility aliases for convenience
        ('Alex Morgan (AI)', 'admin@smartbiz.ai', 'admin123', 'ADMIN', None, None),
        ('Sarah Jenkins (AI)', 'finance@smartbiz.ai', 'finance123', 'FINANCE', dept_fin.id, sd_ap.id),
        ('Rachel Green (AI)', 'hr@smartbiz.ai', 'hr123', 'HR', dept_hr.id, sd_ta.id),
        ('David Ross (AI)', 'sales@smartbiz.ai', 'sales123', 'SALES', dept_sales.id, sd_lm.id),
        ('Michael Chang (AI)', 'support@smartbiz.ai', 'support123', 'SUPPORT', dept_support.id, sd_to.id),
    ]
    for name, email, password, role, dept_id, sub_dept_id in users_data:
        u = User(name=name, email=email, role=role, department_id=dept_id, sub_department_id=sub_dept_id, is_active=True)
        u.set_password(password)
        db.session.add(u)
    db.session.commit()


    # 5. Invoices (Finance & Accounting -> Accounts Payable)
    inv1 = Invoice(
        invoice_number='INV-2026-8801',
        vendor='CloudScale Systems Inc.',
        customer_name='SmartBiz Corp',
        invoice_date='2026-08-10',
        due_date='2026-09-10',
        subtotal=4500.00,
        tax=450.00,
        total=4950.00,
        currency='USD',
        payment_info='ACH Transfer Routing: 021000021 / Acc: 987654321',
        file_name='invoice_cloudscale_8801.pdf',
        file_type='pdf',
        raw_text="CloudScale Systems Inc.\nInvoice #: INV-2026-8801\nDate: 2026-08-10\nDue Date: 2026-09-10\nBill To: SmartBiz Corp\nCloud Infrastructure Tier 3 Hosting: $4,500.00\nSales Tax (10%): $450.00\nTotal Due: $4,950.00",
        extracted_data=json.dumps({
            'vendor': 'CloudScale Systems Inc.',
            'invoice_number': 'INV-2026-8801',
            'subtotal': 4500.0,
            'tax': 450.0,
            'total': 4950.0,
            'currency': 'USD',
            'line_items': [{'description': 'Cloud Hosting Infrastructure', 'quantity': 1, 'amount': 4500.0}]
        }),
        validation_flags=json.dumps(['All mathematical and vendor validations passed']),
        confidence=96,
        status='Processed',
        assigned_department='Finance & Accounting',
        sub_department='Accounts Payable',
        created_at=datetime.now(timezone.utc) - timedelta(days=2)
    )

    inv2 = Invoice(
        invoice_number='INV-2026-9412',
        vendor='Nexus Tech Solutions LLC',
        customer_name='SmartBiz Operations',
        invoice_date='2026-08-14',
        due_date='2026-09-14',
        subtotal=12800.00,
        tax=1280.00,
        total=14080.00,
        currency='USD',
        payment_info='Wire Transfer: Swift CODE NEXUSUS33',
        file_name='nexus_tech_consulting.pdf',
        file_type='pdf',
        raw_text="Nexus Tech Solutions LLC\nInvoice INV-2026-9412\nDate: 2026-08-14\nTotal: $14,080.00",
        extracted_data=json.dumps({
            'vendor': 'Nexus Tech Solutions LLC',
            'invoice_number': 'INV-2026-9412',
            'subtotal': 12800.0,
            'tax': 1280.0,
            'total': 14080.0,
            'currency': 'USD'
        }),
        validation_flags=json.dumps(['All validations passed']),
        confidence=94,
        status='Approved',
        assigned_department='Finance & Accounting',
        sub_department='Accounts Payable',
        created_at=datetime.now(timezone.utc) - timedelta(days=1)
    )

    inv3 = Invoice(
        invoice_number='INV-2026-1049',
        vendor='Apex Global Logistics',
        customer_name='SmartBiz Warehouse',
        invoice_date='2026-08-18',
        due_date='2026-09-18',
        subtotal=3200.00,
        tax=500.00,
        total=3950.00,  # Math variance: 3200 + 500 = 3700 vs 3950
        currency='USD',
        payment_info='Check by Mail to PO Box 4022',
        file_name='apex_logistics_scanned.png',
        file_type='png',
        raw_text="Apex Global Logistics\nInvoice: INV-2026-1049\nSubtotal: $3,200.00\nTax: $500.00\nTotal Due: $3,950.00 (Math variance detected)",
        extracted_data=json.dumps({
            'vendor': 'Apex Global Logistics',
            'invoice_number': 'INV-2026-1049',
            'subtotal': 3200.0,
            'tax': 500.0,
            'total': 3950.0,
            'currency': 'USD'
        }),
        validation_flags=json.dumps([
            "Math Discrepancy: Subtotal ($3,200.00) + Tax ($500.00) = $3,700.00, but document states Total of $3,950.00 (Variance: $250.00)",
            "Low image scan resolution detected"
        ]),
        confidence=52,
        status='Needs Review',
        assigned_department='Finance & Accounting',
        sub_department='Accounts Payable',
        created_at=datetime.now(timezone.utc) - timedelta(hours=5)
    )

    inv4 = Invoice(
        invoice_number='INV-2026-8801',  # Duplicate of inv1
        vendor='CloudScale Systems Inc.',
        customer_name='SmartBiz Corp',
        invoice_date='2026-08-20',
        due_date='2026-09-20',
        subtotal=4500.00,
        tax=450.00,
        total=4950.00,
        currency='USD',
        payment_info='ACH Transfer',
        file_name='duplicate_cloudscale.pdf',
        file_type='pdf',
        raw_text="CloudScale Systems Inc. Duplicate bill submission for INV-2026-8801",
        extracted_data=json.dumps({'vendor': 'CloudScale Systems Inc.', 'invoice_number': 'INV-2026-8801', 'total': 4950.0}),
        validation_flags=json.dumps(["Duplicate Alert: Invoice number 'INV-2026-8801' already exists in system"]),
        confidence=48,
        status='Needs Review',
        assigned_department='Finance & Accounting',
        sub_department='Accounts Payable',
        created_at=datetime.now(timezone.utc) - timedelta(hours=2)
    )
    db.session.add_all([inv1, inv2, inv3, inv4])

    # 6. Expense Claims (Finance & Accounting -> Payroll & Expenses)
    exp1 = ExpenseClaim(
        claim_number='EXP-2026-041',
        employee_name='Sarah Jenkins',
        employee_email='finance@smartbiz.local',
        department='Finance & Accounting',
        category='Software',
        amount=240.00,
        currency='USD',
        description='Monthly subscription for enterprise tax compliance and VAT validation API',
        receipt_file='receipt_tax_api.pdf',
        status='Approved',
        confidence=98,
        assigned_department='Finance & Accounting',
        sub_department='Payroll & Expenses',
        reviewer_name='Alex Morgan',
        created_at=datetime.now(timezone.utc) - timedelta(days=3)
    )
    exp2 = ExpenseClaim(
        claim_number='EXP-2026-042',
        employee_name='David Ross',
        employee_email='sales@smartbiz.local',
        department='Sales & Business Development',
        category='Travel',
        amount=850.00,
        currency='USD',
        description='Client executive onsite presentation flights & lodging for Quantum FinTech deal',
        receipt_file='flight_hotel_receipt.pdf',
        status='Pending',
        confidence=94,
        assigned_department='Finance & Accounting',
        sub_department='Payroll & Expenses',
        created_at=datetime.now(timezone.utc) - timedelta(hours=8)
    )
    exp3 = ExpenseClaim(
        claim_number='EXP-2026-043',
        employee_name='Rachel Green',
        employee_email='hr@smartbiz.local',
        department='Human Resources (HR)',
        category='Equipment',
        amount=350.00,
        currency='USD',
        description='Annual job board premium listing sponsorship for Senior Automation Engineers',
        receipt_file='jobboard_invoice.pdf',
        status='Reimbursed',
        confidence=96,
        assigned_department='Finance & Accounting',
        sub_department='Payroll & Expenses',
        reviewer_name='Sarah Jenkins',
        created_at=datetime.now(timezone.utc) - timedelta(days=5)
    )
    db.session.add_all([exp1, exp2, exp3])
    db.session.commit()

    # 7. Leads (Sales & Business Development -> Lead Management)
    leads_data = [
        Lead(
            name='Elena Rostova',
            email='elena.rostova@quantumfin.io',
            company='Quantum Financial Tech',
            industry='FinTech',
            company_size='1000+',
            budget=85000.0,
            product='Enterprise Automation Suite',
            source='Inbound Demo Request',
            previous_interaction='Requested Executive Live Demo',
            engagement='High',
            score=94,
            category='HOT',
            reason=json.dumps([
                'Substantial enterprise budget ($85,000)',
                '1,000+ employee financial institution in high-growth sector',
                'Executive requested immediate live demonstration'
            ]),
            recommended_action='Assign to Senior Enterprise AE for direct executive demo within 24h',
            recommended_department='Sales & Business Development',
            assigned_department='Sales & Business Development',
            sub_department='Lead Management',
            status='Qualified',
            confidence=95,
            created_at=datetime.now(timezone.utc) - timedelta(days=1)
        ),
        Lead(
            name='Marcus Vance',
            email='m.vance@vanguardlogistics.com',
            company='Vanguard Logistics Group',
            industry='Supply Chain / Logistics',
            company_size='201-1000',
            budget=45000.0,
            product='Document AI & Invoice Module',
            source='Webinar Attendee',
            previous_interaction='Attended AI in Logistics Webinar',
            engagement='High',
            score=86,
            category='HOT',
            reason=json.dumps([
                'Strong mid-market budget ($45,000)',
                'High operational alignment for invoice automation',
                'Actively participated in product Q&A during webinar'
            ]),
            recommended_action='Send custom logistics case study and schedule technical scoping call',
            recommended_department='Sales & Business Development',
            assigned_department='Sales & Business Development',
            sub_department='Lead Management',
            status='Qualified',
            confidence=92,
            created_at=datetime.now(timezone.utc) - timedelta(days=2)
        ),
        Lead(
            name='Samantha Wright',
            email='swright@solardigital.co',
            company='Solar Digital Labs',
            industry='Renewable Energy',
            company_size='51-200',
            budget=15000.0,
            product='Lead & Ticket Automation',
            source='Organic Search',
            previous_interaction='Downloaded Whitepaper',
            engagement='Medium',
            score=68,
            category='WARM',
            reason=json.dumps([
                'Mid-sized company with verified corporate domain',
                'Moderate budget ($15,000)',
                'Downloaded technical whitepaper'
            ]),
            recommended_action='Enroll in automated nurture email series with product ROI calculator',
            recommended_department='Sales & Business Development',
            assigned_department='Sales & Business Development',
            sub_department='Lead Management',
            status='In Review',
            confidence=88,
            created_at=datetime.now(timezone.utc) - timedelta(days=3)
        ),
        Lead(
            name='Brian O\'Connor',
            email='brian@fastfreight.xyz',
            company='FastFreight Direct',
            industry='Transportation',
            company_size='1-10',
            budget=1200.0,
            product='Starter Plan',
            source='Social Media Ad',
            previous_interaction='None',
            engagement='Low',
            score=42,
            category='COLD',
            reason=json.dumps([
                'Small company size (1-10 employees)',
                'Low initial budget ($1,200)',
                'No prior demo or product engagement'
            ]),
            recommended_action='Route to self-serve onboarding drip campaign',
            recommended_department='Sales & Business Development',
            assigned_department='Sales & Business Development',
            sub_department='Lead Management',
            status='New',
            confidence=85,
            created_at=datetime.now(timezone.utc) - timedelta(days=4)
        )
    ]
    db.session.add_all(leads_data)

    # 8. Contract Proposals (Sales & Business Development -> Contract Operations)
    prop1 = ContractProposal(
        proposal_number='PROP-2026-101',
        client_name='Quantum Financial Tech',
        contract_type='Enterprise Master Services Agreement',
        value=85000.00,
        currency='USD',
        effective_date='2026-09-01',
        expiration_date='2027-09-01',
        key_terms='Multi-tenant dedicated GPU deployment, 99.99% uptime SLA, SOC2 Type II compliance audit',
        file_name='quantum_msa_v2.pdf',
        status='In Review',
        confidence=94,
        assigned_department='Sales & Business Development',
        sub_department='Contract Operations',
        created_at=datetime.now(timezone.utc) - timedelta(days=1)
    )
    prop2 = ContractProposal(
        proposal_number='PROP-2026-102',
        client_name='Vanguard Logistics Group',
        contract_type='Annual SaaS Platform Subscription',
        value=45000.00,
        currency='USD',
        effective_date='2026-08-15',
        expiration_date='2027-08-15',
        key_terms='Document AI extraction module, 50,000 monthly invoice parser credits, standard support SLA',
        file_name='vanguard_saas_agreement.pdf',
        status='Approved',
        confidence=96,
        assigned_department='Sales & Business Development',
        sub_department='Contract Operations',
        created_at=datetime.now(timezone.utc) - timedelta(days=3)
    )
    db.session.add_all([prop1, prop2])
    db.session.commit()

    # 9. Job Descriptions & Resumes (Human Resources -> Talent Acquisition)
    jd1 = JobDescription(
        title='Senior Full-Stack Automation Engineer',
        department='Engineering',
        experience_required='4-6 years',
        key_skills=json.dumps(['Python', 'Flask', 'SQL', 'Docker', 'REST APIs', 'System Design', 'JavaScript', 'Html', 'Css', 'Js']),
        description='We are seeking an experienced Full-Stack Engineer to scale our AI-driven business process automation backend. Required proficiency in Python, Flask/FastAPI, SQLAlchemy, asynchronous architectures, and modern web interfaces.',
        is_active=True
    )
    jd2 = JobDescription(
        title='Financial Systems Analyst',
        department='Finance & Accounting',
        experience_required='3-5 years',
        key_skills=json.dumps(['Accounting', 'Financial Modeling', 'Excel', 'ERP Systems', 'Invoice Reconciliation', 'SQL']),
        description='Seeking a detail-oriented Financial Systems Analyst to oversee automated accounts payable workflows, financial audit controls, and ERP data pipelines.',
        is_active=True
    )
    db.session.add_all([jd1, jd2])
    db.session.commit()

    resumes_data = [
        Resume(
            job_id=jd1.id,
            candidate_name='Rahul Sharma',
            email='rahul.sharma.dev@gmail.com',
            phone='+1 (555) 349-8821',
            skills=json.dumps(['Python', 'Flask', 'SQL', 'Docker', 'REST APIs', 'System Design', 'JavaScript', 'AWS', 'Redis']),
            experience='5+ years leading backend microservices and Python web systems.',
            education='B.Tech in Computer Science, IIT Roorkee',
            certifications=json.dumps(['AWS Certified Solutions Architect']),
            match_score=94,
            skills_match_pct=100,
            experience_match_pct=90,
            matching_skills=json.dumps(['Python', 'Flask', 'SQL', 'Docker', 'REST APIs', 'System Design', 'JavaScript']),
            missing_skills=json.dumps([]),
            recommendation='Strong Match',
            ai_summary='Exceptional match across all technical requirements. 5 years direct experience with Python/Flask stacks and distributed architectures.',
            status='Shortlisted',
            interview_date='2026-09-08 14:00',
            interview_status='Scheduled',
            confidence=95,
            assigned_department='Human Resources (HR)',
            sub_department='Talent Acquisition',
            file_name='rahul_sharma_resume.pdf',
            created_at=datetime.now(timezone.utc) - timedelta(days=2)
        ),
        Resume(
            job_id=jd1.id,
            candidate_name='Priya Patel',
            email='priya.patel.code@outlook.com',
            phone='+1 (555) 782-9014',
            skills=json.dumps(['Python', 'Django', 'SQL', 'JavaScript', 'React', 'HTML5', 'CSS3']),
            experience='3.5 years in full-stack web applications and UI interfaces.',
            education='B.S. in Software Engineering, University of Washington',
            certifications=json.dumps(['Certified Scrum Developer']),
            match_score=78,
            skills_match_pct=72,
            experience_match_pct=80,
            matching_skills=json.dumps(['Python', 'SQL', 'JavaScript']),
            missing_skills=json.dumps(['Flask', 'Docker', 'System Design']),
            recommendation='Review',
            ai_summary='Strong frontend and Django background. Would easily adapt to Flask, but Docker and distributed system design skills need verification during technical interview.',
            status='Screened',
            interview_status='Not Scheduled',
            confidence=89,
            assigned_department='Human Resources (HR)',
            sub_department='Talent Acquisition',
            file_name='priya_patel_resume.docx',
            created_at=datetime.now(timezone.utc) - timedelta(days=1)
        ),
        Resume(
            job_id=jd1.id,
            candidate_name='Amit Kumar',
            email='amit.kumar99@yahoo.com',
            phone='+1 (555) 124-7751',
            skills=json.dumps(['HTML5', 'CSS3', 'WordPress', 'Basic PHP', 'SEO']),
            experience='2 years in digital agency web content and basic PHP scripting.',
            education='Diploma in Web Design',
            certifications=json.dumps([]),
            match_score=48,
            skills_match_pct=30,
            experience_match_pct=50,
            matching_skills=json.dumps(['JavaScript']),
            missing_skills=json.dumps(['Python', 'Flask', 'SQL', 'Docker', 'REST APIs', 'System Design']),
            recommendation='Low Match',
            ai_summary='Candidate profile is focused on CMS/WordPress content rather than scalable backend automation engineering.',
            status='Screened',
            interview_status='Not Scheduled',
            confidence=92,
            assigned_department='Human Resources (HR)',
            sub_department='Talent Acquisition',
            file_name='amit_kumar_cv.pdf',
            created_at=datetime.now(timezone.utc) - timedelta(hours=8)
        )
    ]
    db.session.add_all(resumes_data)

    # 10. Employee Documents (Human Resources -> Onboarding & Offboarding)
    emp_doc1 = EmployeeDocument(
        employee_name='Rahul Sharma',
        employee_email='rahul.sharma.dev@gmail.com',
        document_type='W-4 Federal Withholding Form',
        file_name='w4_signed_rahul.pdf',
        verification_status='Verified',
        compliance_notes='Withholding allowances validated and SSN verified against I-9 background check.',
        confidence=98,
        assigned_department='Human Resources (HR)',
        sub_department='Onboarding & Offboarding',
        created_at=datetime.now(timezone.utc) - timedelta(days=1)
    )
    emp_doc2 = EmployeeDocument(
        employee_name='Priya Patel',
        employee_email='priya.patel.code@outlook.com',
        document_type='Proprietary Information & NDA Agreement',
        file_name='nda_priya_patel.pdf',
        verification_status='Verified',
        compliance_notes='Standard mutual non-disclosure and intellectual property assignment executed.',
        confidence=99,
        assigned_department='Human Resources (HR)',
        sub_department='Onboarding & Offboarding',
        created_at=datetime.now(timezone.utc) - timedelta(days=2)
    )
    db.session.add_all([emp_doc1, emp_doc2])
    db.session.commit()

    # 11. Support Tickets & FAQ (Customer Support & Service)
    # Ticket 1: Cross-department routing (Billing -> Finance & Accounting Accounts Payable)
    t1 = SupportTicket(
        ticket_number='TICK-0101',
        customer_name='Jonathan Blake',
        email='jblake@apexglobal.net',
        subject='Payment was deducted twice for August subscription',
        description='Hi SmartBiz Support, I checked my bank account statement this morning and noticed that our monthly enterprise charge of $499 was deducted twice on August 15th. Please refund the duplicate transaction immediately.',
        category='Billing',
        priority='High',
        sentiment='Negative',
        department='Finance & Accounting',
        sub_department='Accounts Payable',
        routed_department='Finance & Accounting',
        routed_sub_department='Accounts Payable',
        routing_status='Routed to Finance & Accounting',
        ai_response=(
            "Dear Jonathan,\n\n"
            "Thank you for contacting SmartBiz Support. We sincerely apologize for any frustration caused regarding the duplicate subscription charge on your account.\n\n"
            "We have escalated your ticket directly to our Finance & Accounting Department (Accounts Payable) for urgent verification. Our billing team will examine transaction logs, reverse the duplicate $499 charge, and ensure your statement is updated within 1-2 business days.\n\n"
            "You will receive a refund confirmation receipt once completed.\n\n"
            "Best regards,\n"
            "SmartBiz Customer Care Team"
        ),
        ai_response_status='Generated',
        ai_reasoning="Classified as Billing due to duplicate charge complaint. Negative sentiment detected; routed to Finance & Accounting (Accounts Payable).",
        faq_match="How do I request an invoice refund for duplicate subscription charges?",
        status='Pending Review',
        confidence=94,
        created_at=datetime.now(timezone.utc) - timedelta(hours=6)
    )

    t2 = SupportTicket(
        ticket_number='TICK-0102',
        customer_name='Claire Sterling',
        email='c.sterling@acmecorp.com',
        subject='Webhook 500 error when receiving invoice payload',
        description='Our automated integration is receiving an intermittent HTTP 500 Internal Server Error when posting JSON webhooks to the /api/invoices endpoint. Logs attached.',
        category='Technical',
        priority='High',
        sentiment='Neutral',
        department='Customer Support & Service',
        sub_department='Ticket Operations',
        routing_status='Internal',
        ai_response=(
            "Dear Claire,\n\n"
            "Thank you for reaching out to SmartBiz Technical Support regarding the intermittent HTTP 500 webhook issue.\n\n"
            "Our engineering team has received your log details and is actively investigating the API endpoint gateway. We will deploy a patch and keep you updated on progress.\n\n"
            "Best regards,\n"
            "SmartBiz Technical Support Team"
        ),
        ai_response_status='Approved',
        ai_reasoning="Classified as Technical due to API webhook 500 failure. Managed by Ticket Operations.",
        faq_match="How do I configure and debug webhook endpoints?",
        status='In Progress',
        confidence=92,
        created_at=datetime.now(timezone.utc) - timedelta(hours=12)
    )

    t3 = SupportTicket(
        ticket_number='TICK-0103',
        customer_name='Liam Henderson',
        email='liam@hendersonpartners.com',
        subject='Inquiry about custom SSO SAML integration for 500 users',
        description='We are planning an enterprise deployment and would like to know if Okta SSO and custom SCIM user provisioning are supported out of the box.',
        category='Product',
        priority='Medium',
        sentiment='Positive',
        department='Sales & Business Development',
        sub_department='Lead Management',
        routed_department='Sales & Business Development',
        routed_sub_department='Lead Management',
        routing_status='Routed to Sales & Business Development',
        ai_response=(
            "Dear Liam,\n\n"
            "Thank you for your interest in SmartBiz Enterprise! Yes, our platform natively supports SAML 2.0 with Okta, Azure AD, and automated SCIM user provisioning.\n\n"
            "Our Enterprise Solutions Team will reach out shortly to provide technical documentation and schedule a walkthrough.\n\n"
            "Best regards,\n"
            "SmartBiz Enterprise Team"
        ),
        ai_response_status='Sent',
        ai_reasoning="Classified as Product/Sales inquiry with Positive sentiment. Routed to Sales.",
        faq_match="What SSO and SAML authentication protocols are supported?",
        status='Resolved',
        confidence=96,
        created_at=datetime.now(timezone.utc) - timedelta(days=1)
    )
    db.session.add_all([t1, t2, t3])

    # FAQ Knowledge Base Articles
    faq1 = FAQArticle(
        question="How do I request an invoice refund for duplicate subscription charges?",
        category="Billing",
        answer="When duplicate charges occur, submit a ticket under Billing. The ticket is automatically routed to Finance & Accounting for ledger audit, and the refund is credited within 1-2 business days.",
        keywords="duplicate charge, refund, billing, payment error",
        usage_count=42,
        is_active=True
    )
    faq2 = FAQArticle(
        question="What SSO and SAML authentication protocols are supported?",
        category="Security & Access",
        answer="SmartBiz Enterprise supports SAML 2.0, Okta, Azure Active Directory, Google Workspace SSO, and automated SCIM 2.0 user directory provisioning.",
        keywords="sso, saml, okta, azure, scim",
        usage_count=29,
        is_active=True
    )
    faq3 = FAQArticle(
        question="How do I configure and debug webhook endpoints?",
        category="Technical",
        answer="Webhooks can be configured under Settings -> Integrations. Ensure your endpoint accepts HTTP POST with JSON content type and responds with HTTP 200 within 5 seconds.",
        keywords="webhook, api, http 500, payload",
        usage_count=18,
        is_active=True
    )
    db.session.add_all([faq1, faq2, faq3])
    db.session.commit()

    # 12. HITL Reviews (Operations & Compliance -> Audit & Governance)
    hitl_inv1 = HITLReview(
        task_type='invoice',
        task_id=inv3.id,
        task_title=f"Invoice #{inv3.invoice_number} ({inv3.vendor})",
        reason="Math Discrepancy: Subtotal ($3,200.00) + Tax ($500.00) != Total ($3,950.00). Variance of $250.00 found.",
        confidence=52,
        original_data=json.dumps({'file_name': 'apex_logistics_scanned.png', 'preview_text': inv3.raw_text}),
        extracted_data=inv3.extracted_data,
        recommended_action="Verify subtotal line items and adjust either Tax or Total before approving.",
        assigned_department='Finance & Accounting',
        sub_department='Audit & Governance',
        action='Pending',
        created_at=datetime.now(timezone.utc) - timedelta(hours=5)
    )

    hitl_inv2 = HITLReview(
        task_type='invoice',
        task_id=inv4.id,
        task_title=f"Invoice #{inv4.invoice_number} ({inv4.vendor})",
        reason="Duplicate Alert: Invoice number 'INV-2026-8801' was already processed on 2026-08-10.",
        confidence=48,
        original_data=json.dumps({'file_name': 'duplicate_cloudscale.pdf', 'preview_text': inv4.raw_text}),
        extracted_data=inv4.extracted_data,
        recommended_action="Confirm whether this is an accidental double submission and reject if duplicate.",
        assigned_department='Finance & Accounting',
        sub_department='Audit & Governance',
        action='Pending',
        created_at=datetime.now(timezone.utc) - timedelta(hours=2)
    )

    hitl_tick = HITLReview(
        task_type='ticket',
        task_id=t1.id,
        task_title=f"Ticket #{t1.ticket_number}: {t1.subject}",
        reason="High sensitivity billing ticket with Negative sentiment. Requires human verification before response dispatch.",
        confidence=94,
        original_data=json.dumps({'customer': t1.customer_name, 'subject': t1.subject, 'description': t1.description}),
        extracted_data=json.dumps({
            'category': t1.category,
            'priority': t1.priority,
            'sentiment': t1.sentiment,
            'department': t1.department,
            'draft_response': t1.ai_response
        }),
        recommended_action="Review AI draft response and approve refund authorization.",
        assigned_department='Finance & Accounting',
        sub_department='Audit & Governance',
        action='Pending',
        created_at=datetime.now(timezone.utc) - timedelta(hours=6)
    )
    db.session.add_all([hitl_inv1, hitl_inv2, hitl_tick])
    db.session.commit()

    # 13. Department-Specific Notifications
    notifications_data = [
        Notification(
            title="⚠️ Invoice Math Discrepancy Flagged",
            message="Invoice INV-2026-1049 from Apex Global Logistics requires Accounts Payable verification ($250 variance).",
            module="Invoices",
            role_target="FINANCE",
            department_id=dept_fin.id,
            link="/finance/accounts-payable"
        ),
        Notification(
            title="💰 New Expense Claim Submitted",
            message="David Ross submitted expense claim EXP-2026-042 for $850.00 (Client Travel).",
            module="Expenses",
            role_target="FINANCE",
            department_id=dept_fin.id,
            link="/finance/payroll-expenses"
        ),
        Notification(
            title="🔥 High-Value HOT Lead Detected",
            message="Elena Rostova (Quantum Financial Tech, $85k budget) scored 94/100 HOT! Assigned to Sales.",
            module="Leads",
            role_target="SALES",
            department_id=dept_sales.id,
            link="/sales/lead-management"
        ),
        Notification(
            title="📄 New Enterprise Contract Proposal",
            message="Proposal PROP-2026-101 for Quantum Financial Tech ($85,000 MSA) uploaded for legal review.",
            module="Contracts",
            role_target="SALES",
            department_id=dept_sales.id,
            link="/sales/contract-operations"
        ),
        Notification(
            title="✨ Strong Candidate Match",
            message="Candidate Rahul Sharma scored 94% match for Senior Full-Stack Automation Engineer.",
            module="Resumes",
            role_target="HR",
            department_id=dept_hr.id,
            link="/hr/talent-acquisition"
        ),
        Notification(
            title="📋 Onboarding Document Verified",
            message="Tax withholding form W-4 for Rahul Sharma passed compliance verification.",
            module="Onboarding",
            role_target="HR",
            department_id=dept_hr.id,
            link="/hr/onboarding-offboarding"
        ),
        Notification(
            title="🚨 High Priority Support Ticket",
            message="Ticket TICK-0101 (Duplicate payment) received and routed to Finance & Accounting.",
            module="Support",
            role_target="SUPPORT",
            department_id=dept_support.id,
            link="/support/ticket-operations"
        ),
        Notification(
            title="🛡️ New HITL Audit Review Required",
            message="Invoice #INV-2026-1049 math variance queued for Audit & Governance oversight.",
            module="Compliance",
            role_target="COMPLIANCE",
            department_id=dept_comp.id,
            link="/compliance/hitl"
        ),
    ]
    db.session.add_all(notifications_data)

    # 14. Activity Logs (Department Scoped)
    logs_data = [
        ActivityLog(user_name='Sarah Jenkins', role='FINANCE', department_name='Finance & Accounting', department_id=dept_fin.id, sub_department_id=sd_ap.id, action='AI Extraction', module='Invoices', description='Extracted and validated INV-2026-8801 with 96% confidence', status='Success'),
        ActivityLog(user_name='Sarah Jenkins', role='FINANCE', department_name='Finance & Accounting', department_id=dept_fin.id, sub_department_id=sd_pe.id, action='Expense Approved', module='Expenses', description='Approved software tools expense claim EXP-2026-041 ($240.00)', status='Success'),
        ActivityLog(user_name='David Ross', role='SALES', department_name='Sales & Business Development', department_id=dept_sales.id, sub_department_id=sd_lm.id, action='Lead Scored', module='Leads', description='Lead Elena Rostova scored HOT (94/100) -> Assigned to Sales', status='Success'),
        ActivityLog(user_name='Rachel Green', role='HR', department_name='Human Resources (HR)', department_id=dept_hr.id, sub_department_id=sd_ta.id, action='Resume Screened', module='Resumes', description='Screened candidate Rahul Sharma against Senior Engineer JD (94% Match)', status='Success'),
        ActivityLog(user_name='Rachel Green', role='HR', department_name='Human Resources (HR)', department_id=dept_hr.id, sub_department_id=sd_oo.id, action='Document Verified', module='Onboarding', description='Verified Form W-4 for new hire Rahul Sharma', status='Success'),
        ActivityLog(user_name='Michael Chang', role='SUPPORT', department_name='Customer Support & Service', department_id=dept_support.id, sub_department_id=sd_to.id, action='Ticket Routed', module='Support', description='Routed Ticket TICK-0101 (Billing issue) to Finance & Accounting', status='Success'),
        ActivityLog(user_name='Elena Vance', role='COMPLIANCE', department_name='Operations & Compliance', department_id=dept_comp.id, sub_department_id=sd_ag.id, action='HITL Audit Logged', module='Compliance', description='Intercepted low confidence invoice INV-2026-1049 for manual verification', status='Warning'),
    ]
    db.session.add_all(logs_data)
    db.session.commit()


    # 10. Generate sample files in uploads/samples directory for easy user testing!
    _generate_sample_files()
    print("Demo database successfully seeded!")

def _generate_sample_files():
    """Generates sample test invoice and resume files in uploads/samples/."""
    samples_dir = Config.SAMPLES_FOLDER
    samples_dir.mkdir(parents=True, exist_ok=True)

    # 1. Sample Clean Invoice (TXT / PDF)
    clean_inv_text = """ACME ENTERPRISE SOLUTIONS INC.
100 Innovation Way, Suite 400, San Francisco, CA 94107
Tax ID: 94-3829102

INVOICE
Invoice Number: INV-2026-7732
Invoice Date: August 25, 2026
Payment Due: September 25, 2026
Billed To: SmartBiz Automation Group

Description                                  Qty    Unit Price     Amount
-------------------------------------------------------------------------
AI Document Processing Platform License        1    $3,000.00   $3,000.00
Cloud Integration Setup & Security Audit       1    $1,500.00   $1,500.00
Dedicated Support SLA (Monthly)                1      $500.00     $500.00

Subtotal: $5,000.00
Tax / GST (10%): $500.00
Total Amount Due: $5,500.00 USD

Payment Instructions:
Bank: Silicon Valley Commercial Bank
Account: 8847291039 | Routing: 121000358
Terms: Net 30 Days
"""
    with open(samples_dir / "sample_clean_invoice.txt", "w", encoding="utf-8") as f:
        f.write(clean_inv_text)

    # 2. Sample Discrepancy Invoice (Triggers HITL)
    discrepancy_inv_text = """SUMMIT LOGISTICS & FREIGHT CORP
Invoice #: INV-2026-9041
Date: August 28, 2026
Due Date: September 28, 2026
Bill To: SmartBiz Global

Line Items:
- Cross-docking and shipping services: $4,200.00
- Warehouse handling fee: $800.00

Subtotal: $5,000.00
Sales Tax (8%): $400.00
Total Amount Due: $5,850.00  (Notice: Math calculation error, 5000 + 400 != 5850)

Payment via Wire Transfer or Corporate Check.
"""
    with open(samples_dir / "sample_math_error_invoice.txt", "w", encoding="utf-8") as f:
        f.write(discrepancy_inv_text)

    # 3. Sample Resume
    sample_resume_text = """ALEXANDER CHEN
alex.chen.engineer@gmail.com | (555) 892-3341 | San Francisco, CA
LinkedIn: linkedin.com/in/alexchen-dev | GitHub: github.com/alexchen-dev

SUMMARY
Experienced Senior Software Engineer with 6+ years specializing in Python backend systems, microservices, REST APIs, and automated business workflows. Passionate about clean system architecture and scalable cloud infrastructure.

TECHNICAL SKILLS
- Languages: Python, JavaScript, TypeScript, SQL, Bash
- Frameworks & Libraries: Flask, FastAPI, Django, SQLAlchemy, React, Node.js
- Cloud & DevOps: Docker, Kubernetes, AWS (ECS, S3, RDS, Lambda), CI/CD (GitHub Actions)
- Databases: PostgreSQL, MySQL, Redis, SQLite
- Methodologies: Agile, Scrum, TDD, Microservices Design

PROFESSIONAL EXPERIENCE
Senior Backend Engineer | CloudFlow Technologies (2022 - Present)
- Architected and built high-throughput REST APIs handling 5M+ daily requests using Python, Flask, and PostgreSQL.
- Containerized legacy services with Docker and Kubernetes, reducing deployment cycle times by 45%.
- Implemented real-time asynchronous job pipelines with Celery and Redis.

Software Engineer | Apex Data Systems (2019 - 2022)
- Developed automated data extraction scripts and ETL pipelines using Python and SQL.
- Designed database schemas and optimized complex queries for high-volume financial transactions.
- Collaborated with frontend engineers to deliver intuitive SaaS dashboard interfaces.

EDUCATION
Bachelor of Science in Computer Science
University of California, Berkeley (2015 - 2019)

CERTIFICATIONS
- AWS Certified Solutions Architect - Associate
- Professional Scrum Developer
"""
    with open(samples_dir / "sample_senior_engineer_resume.txt", "w", encoding="utf-8") as f:
        f.write(sample_resume_text)
