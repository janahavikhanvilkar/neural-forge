import unittest
import json
from app import create_app
from models.models import (
    db, User, Department, SubDepartment, Invoice, Lead, Resume, 
    SupportTicket, HITLReview, JobDescription, ExpenseClaim, 
    ContractProposal, EmployeeDocument, FAQArticle, Notification, ActivityLog
)
from services.ai_service import ai_service
from services.invoice_service import InvoiceService
from services.lead_service import LeadService
from services.resume_service import ResumeService
from services.support_service import SupportService
from services.hitl_service import HITLService
from config import Config

class SmartBizDepartmentAccessControlTest(unittest.TestCase):
    def setUp(self):
        self.app = create_app()
        self.client = self.app.test_client()
        self.ctx = self.app.app_context()
        self.ctx.push()
        from database.seed_data import seed_demo_database
        seed_demo_database()

    def tearDown(self):
        self.ctx.pop()

    def _login_as(self, email, role, dept_code=None, user_id=None):
        """Helper to simulate authenticated session for a specific role and department"""
        with self.client.session_transaction() as sess:
            user = User.query.filter_by(email=email).first()
            sess['user_id'] = user.id if user else (user_id or 1)
            sess['role'] = role.upper()
            sess['user_name'] = user.name if user else f"Test {role}"
            sess['email'] = email
            sess['department_id'] = user.department_id if user else None
            sess['department_code'] = (user.department_code if user else dept_code or '').upper()

    def test_01_departments_and_sub_departments_structure(self):
        """Verify exact 5 Departments and 9 Sub-departments exist in database"""
        depts = Department.query.all()
        self.assertEqual(len(depts), 5)
        dept_codes = {d.code for d in depts}
        self.assertEqual(dept_codes, {'FINANCE', 'HR', 'SALES', 'SUPPORT', 'COMPLIANCE'})

        sub_depts = SubDepartment.query.all()
        self.assertEqual(len(sub_depts), 9)
        sub_codes = {s.code for s in sub_depts}
        expected_subs = {
            'accounts_payable', 'payroll_expenses', 
            'talent_acquisition', 'onboarding_offboarding', 
            'lead_management', 'contract_operations', 
            'ticket_operations', 'response_automation', 
            'audit_governance'
        }
        self.assertEqual(sub_codes, expected_subs)


    def test_02_official_test_accounts_exist(self):
        """Verify all 6 official test accounts with smartbiz123 password"""
        accounts = [
            ('admin@smartbiz.local', 'ADMIN'),
            ('finance@smartbiz.local', 'FINANCE'),
            ('hr@smartbiz.local', 'HR'),
            ('sales@smartbiz.local', 'SALES'),
            ('support@smartbiz.local', 'SUPPORT'),
            ('compliance@smartbiz.local', 'COMPLIANCE'),
        ]
        for email, role in accounts:
            user = User.query.filter_by(email=email).first()
            self.assertIsNotNone(user, f"User {email} must exist in DB")
            self.assertEqual(user.role.upper(), role)
            self.assertTrue(user.check_password('smartbiz123'), f"Password check failed for {email}")

    def test_03_finance_department_access_and_blocking(self):
        """Finance user can access Finance routes but is blocked (403) from other depts"""
        self._login_as('finance@smartbiz.local', 'FINANCE', 'FINANCE')

        # Allowed endpoints
        for ep in ['/finance', '/finance/accounts-payable', '/finance/payroll-expenses', '/invoices', '/tasks', '/activity', '/notifications']:
            resp = self.client.get(ep)
            self.assertEqual(resp.status_code, 200, f"Finance user should access {ep}")

        # Blocked endpoints (403)
        for ep in ['/sales', '/leads', '/hr', '/resumes', '/support-workspace', '/support', '/settings', '/admin/users', '/admin/departments']:
            resp = self.client.get(ep)
            self.assertEqual(resp.status_code, 403, f"Finance user MUST be blocked from {ep} with 403")

    def test_04_hr_department_access_and_blocking(self):
        """HR user can access HR routes but is blocked (403) from other depts"""
        self._login_as('hr@smartbiz.local', 'HR', 'HR')

        # Allowed endpoints
        for ep in ['/hr', '/hr/talent-acquisition', '/hr/onboarding-offboarding', '/resumes', '/tasks', '/activity']:
            resp = self.client.get(ep)
            self.assertEqual(resp.status_code, 200, f"HR user should access {ep}")

        # Blocked endpoints (403)
        for ep in ['/finance', '/invoices', '/sales', '/leads', '/support-workspace', '/support', '/settings', '/admin/users']:
            resp = self.client.get(ep)
            self.assertEqual(resp.status_code, 403, f"HR user MUST be blocked from {ep} with 403")

    def test_05_sales_department_access_and_blocking(self):
        """Sales user can access Sales routes but is blocked (403) from other depts"""
        self._login_as('sales@smartbiz.local', 'SALES', 'SALES')

        # Allowed endpoints
        for ep in ['/sales', '/sales/lead-management', '/sales/contract-operations', '/leads', '/tasks', '/activity']:
            resp = self.client.get(ep)
            self.assertEqual(resp.status_code, 200, f"Sales user should access {ep}")

        # Blocked endpoints (403)
        for ep in ['/finance', '/invoices', '/hr', '/resumes', '/support-workspace', '/compliance', '/settings', '/admin/users']:
            resp = self.client.get(ep)
            self.assertEqual(resp.status_code, 403, f"Sales user MUST be blocked from {ep} with 403")

    def test_06_support_department_access_and_blocking(self):
        """Support user can access Support routes but is blocked (403) from other depts"""
        self._login_as('support@smartbiz.local', 'SUPPORT', 'SUPPORT')

        # Allowed endpoints
        for ep in ['/support-workspace', '/support/ticket-operations', '/support/response-automation', '/support', '/tasks']:
            resp = self.client.get(ep)
            self.assertEqual(resp.status_code, 200, f"Support user should access {ep}")

        # Blocked endpoints (403)
        for ep in ['/finance', '/invoices', '/sales', '/leads', '/hr', '/resumes', '/compliance', '/settings', '/admin/users']:
            resp = self.client.get(ep)
            self.assertEqual(resp.status_code, 403, f"Support user MUST be blocked from {ep} with 403")

    def test_07_compliance_department_access_and_blocking(self):
        """Compliance user can access Compliance & HITL routes but is blocked (403) from settings/admin"""
        self._login_as('compliance@smartbiz.local', 'COMPLIANCE', 'COMPLIANCE')

        # Allowed endpoints
        for ep in ['/compliance', '/compliance/audit-governance', '/hitl', '/tasks', '/activity']:
            resp = self.client.get(ep)
            self.assertEqual(resp.status_code, 200, f"Compliance user should access {ep}")

        # Blocked endpoints (403)
        for ep in ['/finance', '/invoices', '/sales', '/leads', '/hr', '/resumes', '/settings', '/admin/users']:
            resp = self.client.get(ep)
            self.assertEqual(resp.status_code, 403, f"Compliance user MUST be blocked from {ep} with 403")

    def test_08_admin_universal_access(self):
        """Admin has full global access to all department workspaces and administrative panels"""
        self._login_as('admin@smartbiz.local', 'ADMIN', None)

        all_endpoints = [
            '/?overview=true',
            '/finance',
            '/finance/accounts-payable',
            '/finance/payroll-expenses',
            '/hr',
            '/hr/talent-acquisition',
            '/hr/onboarding-offboarding',
            '/sales',
            '/sales/lead-management',
            '/sales/contract-operations',
            '/support-workspace',
            '/support/ticket-operations',
            '/support/response-automation',
            '/compliance',
            '/compliance/audit-governance',
            '/invoices',
            '/leads',
            '/resumes',
            '/support',
            '/hitl',
            '/workflows',
            '/analytics',
            '/settings',
            '/admin/users',
            '/admin/departments',
            '/tasks',
            '/activity',
            '/notifications'
        ]
        for ep in all_endpoints:
            resp = self.client.get(ep)
            self.assertEqual(resp.status_code, 200, f"Admin must have access to {ep}")

    def test_09_sub_department_functional_workflows(self):
        """Test creating and managing records in each sub-department module"""
        # 1. Finance - Expense Claim
        self._login_as('finance@smartbiz.local', 'FINANCE', 'FINANCE')
        resp = self.client.post('/finance/expenses/create', data={
            'employee_name': 'Test Worker',
            'employee_email': 'worker@smartbiz.local',
            'department': 'Finance & Accounting',
            'category': 'Software',
            'amount': 150.00,
            'description': 'Dev tool monthly license'
        }, follow_redirects=True)
        self.assertEqual(resp.status_code, 200)
        claim = ExpenseClaim.query.filter_by(employee_email='worker@smartbiz.local').first()
        self.assertIsNotNone(claim)

        # 2. HR - Employee Document & Interview
        self._login_as('hr@smartbiz.local', 'HR', 'HR')
        resp = self.client.post('/hr/documents/create', data={
            'employee_name': 'New Joiner',
            'employee_email': 'joiner@smartbiz.local',
            'document_type': 'I-9 Employment Eligibility Verification',
            'compliance_notes': 'Passport and SSN verified'
        }, follow_redirects=True)
        self.assertEqual(resp.status_code, 200)
        doc = EmployeeDocument.query.filter_by(employee_email='joiner@smartbiz.local').first()
        self.assertIsNotNone(doc)

        # 3. Sales - Contract Proposal
        self._login_as('sales@smartbiz.local', 'SALES', 'SALES')
        resp = self.client.post('/sales/contracts/create', data={
            'client_name': 'Acme Corp',
            'contract_type': 'Enterprise SaaS Agreement',
            'value': 75000.00,
            'key_terms': '99.9% uptime SLA and 50 seats'
        }, follow_redirects=True)
        self.assertEqual(resp.status_code, 200)
        prop = ContractProposal.query.filter_by(client_name='Acme Corp').first()
        self.assertIsNotNone(prop)

        # 4. Support - FAQ Article & Cross-Department Routing
        self._login_as('support@smartbiz.local', 'SUPPORT', 'SUPPORT')
        resp = self.client.post('/support/faqs/create', data={
            'question': 'How to reset API token?',
            'category': 'Technical',
            'answer': 'Navigate to Settings -> API Keys and click Regenerate Token.',
            'keywords': 'api, token, reset, auth'
        }, follow_redirects=True)
        self.assertEqual(resp.status_code, 200)
        faq = FAQArticle.query.filter_by(question='How to reset API token?').first()
        self.assertIsNotNone(faq)

        # Route a ticket to Finance
        ticket = SupportTicket.query.first()
        resp = self.client.post(f'/support/tickets/{ticket.id}/route', data={
            'target_department': 'Finance & Accounting',
            'target_sub_department': 'Accounts Payable'
        }, follow_redirects=True)
        self.assertEqual(resp.status_code, 200)
        ticket = SupportTicket.query.get(ticket.id)
        self.assertEqual(ticket.routed_department, 'Finance & Accounting')

    def test_10_admin_user_management(self):
        """Admin can create new user, toggle user status, and edit user"""
        self._login_as('admin@smartbiz.local', 'ADMIN', None)

        # Create user
        resp = self.client.post('/admin/users/create', data={
            'name': 'Test New Auditor',
            'email': 'newauditor@smartbiz.local',
            'password': 'smartbiz123',
            'role': 'COMPLIANCE',
            'department_id': 5,
            'sub_department_id': 9
        }, follow_redirects=True)
        self.assertEqual(resp.status_code, 200)
        new_user = User.query.filter_by(email='newauditor@smartbiz.local').first()
        self.assertIsNotNone(new_user)
        self.assertEqual(new_user.role, 'COMPLIANCE')

        # Toggle status
        resp = self.client.post(f'/admin/users/{new_user.id}/toggle-status', follow_redirects=True)
        self.assertEqual(resp.status_code, 200)
        new_user = User.query.get(new_user.id)
        self.assertFalse(new_user.is_active)

    def test_11_invoice_processing_pipeline(self):
        """Test invoice file extraction and confidence calculation"""
        sample_file = Config.SAMPLES_FOLDER / "sample_clean_invoice.txt"
        self.assertTrue(sample_file.exists())

        inv = InvoiceService.process_invoice_file(str(sample_file), "sample_clean_invoice.txt")
        self.assertIsNotNone(inv)
        self.assertGreaterEqual(inv.confidence, 80)
        self.assertEqual(inv.status, 'Processed')
        self.assertEqual(inv.assigned_department, 'Finance & Accounting')

        # Math error invoice triggers HITL
        err_file = Config.SAMPLES_FOLDER / "sample_math_error_invoice.txt"
        inv_err = InvoiceService.process_invoice_file(str(err_file), "sample_math_error_invoice.txt")
        self.assertIsNotNone(inv_err)
        self.assertEqual(inv_err.status, 'Needs Review')

        hitl = HITLReview.query.filter_by(task_type='invoice', task_id=inv_err.id).first()
        self.assertIsNotNone(hitl)
        self.assertEqual(hitl.action, 'Pending')

    def test_12_lead_scoring_pipeline(self):
        """Test lead scoring and categorization"""
        hot_lead_data = {
            'name': 'Sophia Loren',
            'email': 'sophia@enterprisecorp.com',
            'company': 'Enterprise Global Inc.',
            'industry': 'Financial Technology',
            'company_size': '1000+',
            'budget': 65000,
            'product': 'Automation Platform',
            'source': 'Inbound Demo Request',
            'previous_interaction': 'Requested Live Demo',
            'engagement': 'High'
        }
        lead = LeadService.create_and_score_lead(hot_lead_data)
        self.assertIsNotNone(lead)
        self.assertGreaterEqual(lead.score, 80)
        self.assertEqual(lead.category, 'HOT')
        self.assertEqual(lead.assigned_department, 'Sales & Business Development')

    def test_13_resume_screening_pipeline(self):
        """Test resume parsing and match score ranking"""
        sample_resume = Config.SAMPLES_FOLDER / "sample_senior_engineer_resume.txt"
        self.assertTrue(sample_resume.exists())

        jd = JobDescription.query.first()
        self.assertIsNotNone(jd)

        resume = ResumeService.screen_resume_file(str(sample_resume), "sample_senior_engineer_resume.txt", jd.id)
        self.assertIsNotNone(resume)
        self.assertGreaterEqual(resume.match_score, 75)
        self.assertIn(resume.recommendation, ['Strong Match', 'Review'])

    def test_14_support_ticket_pipeline(self):
        """Test support ticket categorization, priority scoring, and AI responses"""
        ticket_data = {
            'customer_name': 'Robert Taylor',
            'email': 'rtaylor@clientcorp.com',
            'subject': 'Charged twice for monthly invoice',
            'description': 'Our account was billed $1,200 twice on the 1st of this month. Please issue a refund.'
        }
        ticket = SupportService.create_and_classify_ticket(ticket_data)
        self.assertIsNotNone(ticket)
        self.assertEqual(ticket.category, 'Billing')
        self.assertEqual(ticket.department, 'Finance & Accounting')
        self.assertIsNotNone(ticket.ai_response)

        # Test approving and sending response
        updated_ticket = SupportService.approve_and_send_response(ticket.id, ticket.ai_response, 'Support Agent')
        self.assertEqual(updated_ticket.status, 'Resolved')
        self.assertEqual(updated_ticket.ai_response_status, 'Sent')

    def test_15_hitl_resolution_pipeline(self):
        """Test resolving pending human-in-the-loop audit task"""
        pending_review = HITLReview.query.filter_by(action='Pending').first()
        self.assertIsNotNone(pending_review)

        resolved = HITLService.resolve_review(
            review_id=pending_review.id,
            action='Approved',
            reviewer_name='Test Reviewer',
            comment='Verified and approved during automated tests'
        )
        self.assertEqual(resolved.action, 'Approved')

if __name__ == '__main__':
    unittest.main()


