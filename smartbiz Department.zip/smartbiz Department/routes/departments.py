from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify, session
from models.models import (
    db, User, Department, SubDepartment, Invoice, ExpenseClaim,
    Lead, ContractProposal, JobDescription, Resume, EmployeeDocument,
    SupportTicket, FAQArticle, HITLReview, ActivityLog, Notification, SystemSetting
)
from utils.helpers import login_required, department_required, admin_required, log_activity, create_notification, get_current_user
from datetime import datetime, timezone
import json

departments_bp = Blueprint('departments', __name__)

# =========================================================================
# 1. FINANCE WORKSPACE & SUB-DEPARTMENTS
# =========================================================================

@departments_bp.route('/finance')
@departments_bp.route('/finance/dashboard')
@departments_bp.route('/finance/workspace')
@department_required('FINANCE')
def finance_workspace():
    """Finance & Accounting Department Workspace."""
    invoices = Invoice.query.order_by(Invoice.created_at.desc()).all()
    expense_claims = ExpenseClaim.query.order_by(ExpenseClaim.created_at.desc()).all()
    
    total_spend = sum(inv.total or 0 for inv in invoices if inv.status == 'Processed' or inv.status == 'Approved')
    pending_invoices = [i for i in invoices if i.status == 'Needs Review' or i.status == 'Pending']
    pending_expenses = [e for e in expense_claims if e.status == 'Pending']
    
    # Cross-department routed billing tickets
    routed_tickets = SupportTicket.query.filter(
        (SupportTicket.department.like('%Finance%')) | (SupportTicket.routed_department.like('%Finance%'))
    ).order_by(SupportTicket.created_at.desc()).all()

    return render_template(
        'departments/finance_workspace.html',
        invoices=invoices,
        expense_claims=expense_claims,
        pending_invoices=pending_invoices,
        pending_expenses=pending_expenses,
        routed_tickets=routed_tickets,
        total_spend=total_spend,
        active_sub_dept='all'
    )

@departments_bp.route('/finance/accounts-payable')
@department_required('FINANCE')
def accounts_payable():
    """Finance Sub-department: Accounts Payable (Invoices)."""
    invoices = Invoice.query.order_by(Invoice.created_at.desc()).all()
    pending_invoices = [i for i in invoices if i.status in ('Needs Review', 'Pending')]
    processed_invoices = [i for i in invoices if i.status in ('Processed', 'Approved')]
    
    return render_template(
        'departments/finance_workspace.html',
        invoices=invoices,
        pending_invoices=pending_invoices,
        processed_invoices=processed_invoices,
        expense_claims=[],
        pending_expenses=[],
        routed_tickets=[],
        active_sub_dept='accounts_payable'
    )

@departments_bp.route('/finance/payroll-expenses')
@department_required('FINANCE')
def payroll_expenses():
    """Finance Sub-department: Payroll & Expenses (Expense Claims)."""
    expense_claims = ExpenseClaim.query.order_by(ExpenseClaim.created_at.desc()).all()
    pending_expenses = [e for e in expense_claims if e.status == 'Pending']
    
    return render_template(
        'departments/finance_workspace.html',
        invoices=[],
        pending_invoices=[],
        expense_claims=expense_claims,
        pending_expenses=pending_expenses,
        routed_tickets=[],
        active_sub_dept='payroll_expenses'
    )

@departments_bp.route('/finance/expenses/create', methods=['POST'])
@department_required('FINANCE')
def create_expense_claim():
    """Submit a new employee expense claim."""
    employee_name = request.form.get('employee_name', '').strip()
    employee_email = request.form.get('employee_email', '').strip()
    department = request.form.get('department', 'Finance & Accounting').strip()
    category = request.form.get('category', 'General').strip()
    amount = float(request.form.get('amount', 0.0))
    description = request.form.get('description', '').strip()
    
    count = ExpenseClaim.query.count() + 1
    claim_num = f"EXP-2026-{count:03d}"
    
    claim = ExpenseClaim(
        claim_number=claim_num,
        employee_name=employee_name,
        employee_email=employee_email,
        department=department,
        category=category,
        amount=amount,
        description=description,
        status='Pending',
        confidence=95,
        assigned_department='Finance & Accounting',
        sub_department='Payroll & Expenses'
    )
    db.session.add(claim)
    db.session.commit()
    
    log_activity(
        action='Expense Claim Created',
        module='Expenses',
        description=f"Created expense claim {claim_num} for {employee_name} (${amount:.2f})",
        department_name='Finance & Accounting'
    )
    flash(f'Expense claim {claim_num} created successfully.', 'success')
    return redirect(url_for('departments.payroll_expenses'))

@departments_bp.route('/finance/expenses/<int:claim_id>/action', methods=['POST'])
@department_required('FINANCE')
def update_expense_status(claim_id):
    """Approve, Reject, or Reimburse an expense claim."""
    claim = ExpenseClaim.query.get_or_404(claim_id)
    new_status = request.form.get('status', 'Approved')
    
    claim.status = new_status
    claim.reviewer_name = session.get('user_name', 'Finance Reviewer')
    db.session.commit()
    
    log_activity(
        action='Expense Status Updated',
        module='Expenses',
        description=f"Expense claim {claim.claim_number} updated to {new_status}",
        department_name='Finance & Accounting'
    )
    flash(f'Expense claim {claim.claim_number} marked as {new_status}.', 'success')
    return redirect(url_for('departments.payroll_expenses'))

# =========================================================================
# 2. HR WORKSPACE & SUB-DEPARTMENTS
# =========================================================================

@departments_bp.route('/hr')
@departments_bp.route('/hr/dashboard')
@departments_bp.route('/hr/workspace')
@department_required('HR')
def hr_workspace():
    """Human Resources Department Workspace."""
    resumes = Resume.query.order_by(Resume.match_score.desc()).all()
    employee_docs = EmployeeDocument.query.order_by(EmployeeDocument.created_at.desc()).all()
    job_descriptions = JobDescription.query.filter_by(is_active=True).all()
    
    shortlisted = [r for r in resumes if r.status == 'Shortlisted']
    interviews_scheduled = [r for r in resumes if r.interview_status == 'Scheduled']
    
    return render_template(
        'departments/hr_workspace.html',
        resumes=resumes,
        employee_docs=employee_docs,
        job_descriptions=job_descriptions,
        shortlisted=shortlisted,
        interviews_scheduled=interviews_scheduled,
        active_sub_dept='all'
    )

@departments_bp.route('/hr/talent-acquisition')
@department_required('HR')
def talent_acquisition():
    """HR Sub-department: Talent Acquisition."""
    resumes = Resume.query.order_by(Resume.match_score.desc()).all()
    job_descriptions = JobDescription.query.filter_by(is_active=True).all()
    shortlisted = [r for r in resumes if r.status == 'Shortlisted']
    interviews_scheduled = [r for r in resumes if r.interview_status == 'Scheduled']
    
    return render_template(
        'departments/hr_workspace.html',
        resumes=resumes,
        employee_docs=[],
        job_descriptions=job_descriptions,
        shortlisted=shortlisted,
        interviews_scheduled=interviews_scheduled,
        active_sub_dept='talent_acquisition'
    )

@departments_bp.route('/hr/onboarding-offboarding')
@department_required('HR')
def onboarding_offboarding():
    """HR Sub-department: Onboarding & Offboarding (Employee Documents)."""
    employee_docs = EmployeeDocument.query.order_by(EmployeeDocument.created_at.desc()).all()
    
    return render_template(
        'departments/hr_workspace.html',
        resumes=[],
        employee_docs=employee_docs,
        job_descriptions=[],
        shortlisted=[],
        interviews_scheduled=[],
        active_sub_dept='onboarding_offboarding'
    )

@departments_bp.route('/hr/resumes/<int:resume_id>/schedule-interview', methods=['POST'])
@department_required('HR')
def schedule_interview(resume_id):
    """Schedule or update candidate interview."""
    resume = Resume.query.get_or_404(resume_id)
    interview_date = request.form.get('interview_date', '').strip()
    
    resume.interview_date = interview_date
    resume.interview_status = 'Scheduled'
    resume.status = 'Shortlisted'
    db.session.commit()
    
    log_activity(
        action='Interview Scheduled',
        module='Resumes',
        description=f"Scheduled interview for {resume.candidate_name} on {interview_date}",
        department_name='Human Resources (HR)'
    )
    flash(f"Interview scheduled for {resume.candidate_name} on {interview_date}.", 'success')
    return redirect(url_for('departments.talent_acquisition'))

@departments_bp.route('/hr/documents/create', methods=['POST'])
@department_required('HR')
def create_employee_document():
    """Add an employee onboarding document."""
    employee_name = request.form.get('employee_name', '').strip()
    employee_email = request.form.get('employee_email', '').strip()
    document_type = request.form.get('document_type', 'ID Verification').strip()
    compliance_notes = request.form.get('compliance_notes', '').strip()
    
    doc = EmployeeDocument(
        employee_name=employee_name,
        employee_email=employee_email,
        document_type=document_type,
        compliance_notes=compliance_notes,
        verification_status='Verified',
        confidence=98,
        assigned_department='Human Resources (HR)',
        sub_department='Onboarding & Offboarding'
    )
    db.session.add(doc)
    db.session.commit()
    
    log_activity(
        action='Employee Document Added',
        module='Onboarding',
        description=f"Verified {document_type} for employee {employee_name}",
        department_name='Human Resources (HR)'
    )
    flash(f"Document for {employee_name} recorded successfully.", 'success')
    return redirect(url_for('departments.onboarding_offboarding'))

# =========================================================================
# 3. SALES WORKSPACE & SUB-DEPARTMENTS
# =========================================================================

@departments_bp.route('/sales')
@departments_bp.route('/sales/dashboard')
@departments_bp.route('/sales/workspace')
@department_required('SALES')
def sales_workspace():
    """Sales & Business Development Department Workspace."""
    leads = Lead.query.order_by(Lead.score.desc()).all()
    proposals = ContractProposal.query.order_by(ContractProposal.created_at.desc()).all()
    
    hot_leads = [l for l in leads if l.category == 'HOT']
    total_pipeline = sum(l.budget or 0 for l in leads)
    total_contract_value = sum(p.value or 0 for p in proposals)
    
    return render_template(
        'departments/sales_workspace.html',
        leads=leads,
        proposals=proposals,
        hot_leads=hot_leads,
        total_pipeline=total_pipeline,
        total_contract_value=total_contract_value,
        active_sub_dept='all'
    )

@departments_bp.route('/sales/lead-management')
@department_required('SALES')
def lead_management():
    """Sales Sub-department: Lead Management."""
    leads = Lead.query.order_by(Lead.score.desc()).all()
    hot_leads = [l for l in leads if l.category == 'HOT']
    total_pipeline = sum(l.budget or 0 for l in leads)
    
    return render_template(
        'departments/sales_workspace.html',
        leads=leads,
        proposals=[],
        hot_leads=hot_leads,
        total_pipeline=total_pipeline,
        total_contract_value=0,
        active_sub_dept='lead_management'
    )

@departments_bp.route('/sales/contract-operations')
@department_required('SALES')
def contract_operations():
    """Sales Sub-department: Contract Operations."""
    proposals = ContractProposal.query.order_by(ContractProposal.created_at.desc()).all()
    total_contract_value = sum(p.value or 0 for p in proposals)
    
    return render_template(
        'departments/sales_workspace.html',
        leads=[],
        proposals=proposals,
        hot_leads=[],
        total_pipeline=0,
        total_contract_value=total_contract_value,
        active_sub_dept='contract_operations'
    )

@departments_bp.route('/sales/contracts/create', methods=['POST'])
@department_required('SALES')
def create_contract_proposal():
    """Add a new contract proposal."""
    client_name = request.form.get('client_name', '').strip()
    contract_type = request.form.get('contract_type', 'Enterprise SaaS Agreement').strip()
    value = float(request.form.get('value', 0.0))
    key_terms = request.form.get('key_terms', '').strip()
    
    count = ContractProposal.query.count() + 1
    proposal_number = f"PROP-2026-{count:03d}"
    
    prop = ContractProposal(
        proposal_number=proposal_number,
        client_name=client_name,
        contract_type=contract_type,
        value=value,
        key_terms=key_terms,
        status='In Review',
        confidence=94,
        assigned_department='Sales & Business Development',
        sub_department='Contract Operations'
    )
    db.session.add(prop)
    db.session.commit()
    
    log_activity(
        action='Contract Proposal Created',
        module='Contracts',
        description=f"Created proposal {proposal_number} for {client_name} (${value:,.2f})",
        department_name='Sales & Business Development'
    )
    flash(f"Proposal {proposal_number} submitted for review.", 'success')
    return redirect(url_for('departments.contract_operations'))

@departments_bp.route('/sales/contracts/<int:contract_id>/status', methods=['POST'])
@department_required('SALES')
def update_contract_status(contract_id):
    """Update contract proposal status."""
    prop = ContractProposal.query.get_or_404(contract_id)
    new_status = request.form.get('status', 'Approved')
    
    prop.status = new_status
    db.session.commit()
    
    log_activity(
        action='Contract Status Updated',
        module='Contracts',
        description=f"Contract proposal {prop.proposal_number} marked as {new_status}",
        department_name='Sales & Business Development'
    )
    flash(f"Contract {prop.proposal_number} marked as {new_status}.", 'success')
    return redirect(url_for('departments.contract_operations'))

# =========================================================================
# 4. CUSTOMER SUPPORT WORKSPACE & SUB-DEPARTMENTS
# =========================================================================

@departments_bp.route('/support-workspace')
@departments_bp.route('/support/workspace')
@departments_bp.route('/support/dashboard')
@department_required('SUPPORT')
def support_workspace():
    """Customer Support & Service Workspace."""
    tickets = SupportTicket.query.order_by(SupportTicket.created_at.desc()).all()
    faqs = FAQArticle.query.filter_by(is_active=True).all()
    
    open_tickets = [t for t in tickets if t.status in ('Open', 'In Progress', 'Pending Review')]
    critical_tickets = [t for t in tickets if t.priority in ('High', 'Critical')]
    
    return render_template(
        'departments/support_workspace.html',
        tickets=tickets,
        faqs=faqs,
        open_tickets=open_tickets,
        critical_tickets=critical_tickets,
        active_sub_dept='all'
    )

@departments_bp.route('/support/ticket-operations')
@department_required('SUPPORT')
def ticket_operations():
    """Support Sub-department: Ticket Operations."""
    tickets = SupportTicket.query.order_by(SupportTicket.created_at.desc()).all()
    open_tickets = [t for t in tickets if t.status in ('Open', 'In Progress', 'Pending Review')]
    critical_tickets = [t for t in tickets if t.priority in ('High', 'Critical')]
    
    return render_template(
        'departments/support_workspace.html',
        tickets=tickets,
        faqs=[],
        open_tickets=open_tickets,
        critical_tickets=critical_tickets,
        active_sub_dept='ticket_operations'
    )

@departments_bp.route('/support/response-automation')
@department_required('SUPPORT')
def response_automation():
    """Support Sub-department: Response Automation & FAQ Articles."""
    faqs = FAQArticle.query.order_by(FAQArticle.usage_count.desc()).all()
    
    return render_template(
        'departments/support_workspace.html',
        tickets=[],
        faqs=faqs,
        open_tickets=[],
        critical_tickets=[],
        active_sub_dept='response_automation'
    )

@departments_bp.route('/support/faqs/create', methods=['POST'])
@department_required('SUPPORT')
def create_faq_article():
    """Add a new FAQ article to knowledge base."""
    question = request.form.get('question', '').strip()
    category = request.form.get('category', 'General').strip()
    answer = request.form.get('answer', '').strip()
    keywords = request.form.get('keywords', '').strip()
    
    faq = FAQArticle(
        question=question,
        category=category,
        answer=answer,
        keywords=keywords,
        usage_count=1,
        is_active=True
    )
    db.session.add(faq)
    db.session.commit()
    
    log_activity(
        action='FAQ Article Created',
        module='Support',
        description=f"Added knowledge base FAQ: {question[:50]}...",
        department_name='Customer Support & Service'
    )
    flash('Knowledge base article published successfully.', 'success')
    return redirect(url_for('departments.response_automation'))

@departments_bp.route('/support/tickets/<int:ticket_id>/route', methods=['POST'])
@department_required('SUPPORT')
def route_support_ticket(ticket_id):
    """Route a support ticket to another department (e.g., Billing -> Finance)."""
    ticket = SupportTicket.query.get_or_404(ticket_id)
    target_dept = request.form.get('target_department', 'Finance & Accounting').strip()
    target_sub_dept = request.form.get('target_sub_department', 'Accounts Payable').strip()
    
    ticket.routed_department = target_dept
    ticket.routed_sub_department = target_sub_dept
    ticket.routing_status = f"Routed to {target_dept}"
    db.session.commit()
    
    log_activity(
        action='Ticket Cross-Routed',
        module='Support',
        description=f"Routed ticket {ticket.ticket_number} to {target_dept} ({target_sub_dept})",
        department_name='Customer Support & Service'
    )
    create_notification(
        title=f"📨 Support Ticket Cross-Routed: {ticket.ticket_number}",
        message=f"Ticket {ticket.ticket_number} ({ticket.subject}) was routed from Support to {target_dept}.",
        module='Support',
        role_target='FINANCE' if 'Finance' in target_dept else 'ALL',
        link='/finance/accounts-payable' if 'Finance' in target_dept else '/dashboard'
    )
    flash(f"Ticket {ticket.ticket_number} successfully routed to {target_dept}.", 'success')
    return redirect(url_for('departments.ticket_operations'))

# =========================================================================
# 5. OPERATIONS & COMPLIANCE WORKSPACE
# =========================================================================

@departments_bp.route('/compliance')
@departments_bp.route('/compliance/dashboard')
@departments_bp.route('/compliance/workspace')
@department_required('COMPLIANCE')
def compliance_workspace():
    """Operations & Compliance Department Workspace."""
    hitl_reviews = HITLReview.query.order_by(HITLReview.created_at.desc()).all()
    logs = ActivityLog.query.order_by(ActivityLog.created_at.desc()).limit(20).all()
    
    pending_reviews = [r for r in hitl_reviews if r.action == 'Pending']
    completed_reviews = [r for r in hitl_reviews if r.action != 'Pending']
    
    return render_template(
        'departments/compliance_workspace.html',
        hitl_reviews=hitl_reviews,
        pending_reviews=pending_reviews,
        completed_reviews=completed_reviews,
        logs=logs,
        active_sub_dept='all'
    )

@departments_bp.route('/compliance/audit-governance')
@department_required('COMPLIANCE')
def audit_governance():
    """Compliance Sub-department: Audit & Governance."""
    hitl_reviews = HITLReview.query.order_by(HITLReview.created_at.desc()).all()
    pending_reviews = [r for r in hitl_reviews if r.action == 'Pending']
    completed_reviews = [r for r in hitl_reviews if r.action != 'Pending']
    logs = ActivityLog.query.order_by(ActivityLog.created_at.desc()).limit(30).all()
    
    return render_template(
        'departments/compliance_workspace.html',
        hitl_reviews=hitl_reviews,
        pending_reviews=pending_reviews,
        completed_reviews=completed_reviews,
        logs=logs,
        active_sub_dept='audit_governance'
    )

# =========================================================================
# 6. DEPARTMENT-SCOPED TASKS, ACTIVITY, AND NOTIFICATIONS
# =========================================================================

@departments_bp.route('/tasks')
@login_required
def department_tasks():
    """
    Department-scoped tasks queue.
    Department users ONLY see tasks assigned to their department.
    Admin sees all tasks across all departments.
    """
    user = get_current_user()
    role = (user.role or '').upper()
    dept_code = (user.department_code or '').upper()
    
    # Invoices tasks (Needs Review / Pending)
    inv_query = Invoice.query.filter(Invoice.status.in_(['Needs Review', 'Pending']))
    # Leads tasks (HOT / In Review)
    lead_query = Lead.query.filter(Lead.status.in_(['New', 'In Review', 'Qualified']))
    # Resumes tasks (Screened / Shortlisted)
    resume_query = Resume.query.filter(Resume.status.in_(['Screened', 'Shortlisted']))
    # Support tasks (Open / Pending Review)
    ticket_query = SupportTicket.query.filter(SupportTicket.status.in_(['Open', 'Pending Review']))
    # HITL tasks (Pending)
    hitl_query = HITLReview.query.filter_by(action='Pending')
    
    if role != 'ADMIN':
        if dept_code == 'FINANCE':
            inv_tasks = inv_query.all()
            lead_tasks, resume_tasks, ticket_tasks, hitl_tasks = [], [], [], []
        elif dept_code == 'SALES':
            lead_tasks = lead_query.all()
            inv_tasks, resume_tasks, ticket_tasks, hitl_tasks = [], [], [], []
        elif dept_code == 'HR':
            resume_tasks = resume_query.all()
            inv_tasks, lead_tasks, ticket_tasks, hitl_tasks = [], [], [], []
        elif dept_code == 'SUPPORT':
            ticket_tasks = ticket_query.all()
            inv_tasks, lead_tasks, resume_tasks, hitl_tasks = [], [], [], []
        elif dept_code == 'COMPLIANCE':
            hitl_tasks = hitl_query.all()
            inv_tasks, lead_tasks, resume_tasks, ticket_tasks = [], [], [], []
        else:
            inv_tasks, lead_tasks, resume_tasks, ticket_tasks, hitl_tasks = [], [], [], [], []
    else:
        # Admin sees everything
        inv_tasks = inv_query.all()
        lead_tasks = lead_query.all()
        resume_tasks = resume_query.all()
        ticket_tasks = ticket_query.all()
        hitl_tasks = hitl_query.all()

    total_tasks = len(inv_tasks) + len(lead_tasks) + len(resume_tasks) + len(ticket_tasks) + len(hitl_tasks)

    return render_template(
        'departments/department_tasks.html',
        inv_tasks=inv_tasks,
        lead_tasks=lead_tasks,
        resume_tasks=resume_tasks,
        ticket_tasks=ticket_tasks,
        hitl_tasks=hitl_tasks,
        total_tasks=total_tasks,
        user_department=user.department_name,
        user_role=role
    )

@departments_bp.route('/activity')
@login_required
def department_activity():
    """
    Department-scoped activity audit trail.
    Department users ONLY see activity logs belonging to their department.
    Admin sees all global audit logs.
    """
    user = get_current_user()
    role = (user.role or '').upper()
    dept_code = (user.department_code or '').upper()
    
    if role == 'ADMIN':
        logs = ActivityLog.query.order_by(ActivityLog.created_at.desc()).limit(100).all()
    else:
        logs = ActivityLog.query.filter(
            (ActivityLog.department_name.like(f"%{user.department_name}%")) |
            (ActivityLog.role == role) |
            (ActivityLog.user_id == user.id)
        ).order_by(ActivityLog.created_at.desc()).limit(50).all()

    return render_template(
        'departments/department_activity.html',
        logs=logs,
        user_department=user.department_name,
        user_role=role
    )

@departments_bp.route('/notifications')
@login_required
def department_notifications():
    """
    Department-scoped notifications center.
    """
    user = get_current_user()
    role = (user.role or '').upper()
    
    if role == 'ADMIN':
        notifications = Notification.query.order_by(Notification.created_at.desc()).all()
    else:
        notifications = Notification.query.filter(
            (Notification.role_target.in_(['ALL', role])) |
            (Notification.department_id == user.department_id) |
            (Notification.user_id == user.id)
        ).order_by(Notification.created_at.desc()).all()

    return render_template(
        'departments/department_notifications.html',
        notifications=notifications,
        user_department=user.department_name,
        user_role=role
    )

# =========================================================================
# 7. ADMIN CONTROLS: USER & DEPARTMENT MANAGEMENT
# =========================================================================

@departments_bp.route('/admin/users')
@admin_required
def admin_users():
    """Admin: User Management."""
    users = User.query.order_by(User.id.asc()).all()
    departments = Department.query.order_by(Department.id.asc()).all()
    sub_departments = SubDepartment.query.order_by(SubDepartment.id.asc()).all()
    
    return render_template(
        'admin/users.html',
        users=users,
        departments=departments,
        sub_departments=sub_departments
    )

@departments_bp.route('/admin/users/create', methods=['POST'])
@admin_required
def admin_create_user():
    """Admin: Create a new user with role and department assignment."""
    name = request.form.get('name', '').strip()
    email = request.form.get('email', '').strip().lower()
    password = request.form.get('password', 'smartbiz123').strip()
    role = request.form.get('role', 'FINANCE').strip().upper()
    dept_id = request.form.get('department_id')
    sub_dept_id = request.form.get('sub_department_id')
    
    if User.query.filter_by(email=email).first():
        flash(f'User with email {email} already exists.', 'danger')
        return redirect(url_for('departments.admin_users'))
    
    dept_id_val = int(dept_id) if dept_id and dept_id.isdigit() else None
    sub_dept_id_val = int(sub_dept_id) if sub_dept_id and sub_dept_id.isdigit() else None
    
    user = User(
        name=name,
        email=email,
        role=role,
        department_id=dept_id_val,
        sub_department_id=sub_dept_id_val,
        is_active=True
    )
    user.set_password(password)
    db.session.add(user)
    db.session.commit()
    
    log_activity(
        action='User Created',
        module='Admin',
        description=f"Admin created user {name} ({email}) with role {role}",
        department_name='Administration'
    )
    flash(f"User {name} created successfully.", 'success')
    return redirect(url_for('departments.admin_users'))

@departments_bp.route('/admin/users/<int:user_id>/toggle-status', methods=['POST'])
@admin_required
def admin_toggle_user_status(user_id):
    """Admin: Activate or Deactivate a user account."""
    user = User.query.get_or_404(user_id)
    if user.email == session.get('user_email'):
        flash('You cannot deactivate your own admin account.', 'danger')
        return redirect(url_for('departments.admin_users'))
    
    user.is_active = not user.is_active
    db.session.commit()
    
    status_str = 'Activated' if user.is_active else 'Deactivated'
    log_activity(
        action=f'User {status_str}',
        module='Admin',
        description=f"Admin {status_str.lower()} account for {user.name} ({user.email})",
        department_name='Administration'
    )
    flash(f"Account for {user.name} has been {status_str.lower()}.", 'info')
    return redirect(url_for('departments.admin_users'))

@departments_bp.route('/admin/users/<int:user_id>/edit', methods=['POST'])
@admin_required
def admin_edit_user(user_id):
    """Admin: Reassign department, sub-department, and role."""
    user = User.query.get_or_404(user_id)
    
    name = request.form.get('name', user.name).strip()
    role = request.form.get('role', user.role).strip().upper()
    dept_id = request.form.get('department_id')
    sub_dept_id = request.form.get('sub_department_id')
    
    user.name = name
    user.role = role
    user.department_id = int(dept_id) if dept_id and dept_id.isdigit() else None
    user.sub_department_id = int(sub_dept_id) if sub_dept_id and sub_dept_id.isdigit() else None
    
    db.session.commit()
    
    log_activity(
        action='User Updated',
        module='Admin',
        description=f"Updated permissions for {user.name}: Role={role}, Dept={user.department_name}",
        department_name='Administration'
    )
    flash(f"User {user.name} updated successfully.", 'success')
    return redirect(url_for('departments.admin_users'))

@departments_bp.route('/admin/departments')
@admin_required
def admin_departments():
    """Admin: Department & Sub-department Overview."""
    departments = Department.query.order_by(Department.id.asc()).all()
    
    # Calculate stats per department
    stats = {}
    for d in departments:
        member_count = User.query.filter_by(department_id=d.id, is_active=True).count()
        sub_dept_count = len(d.sub_departments)
        
        # Determine items count based on department
        if d.code == 'FINANCE':
            item_count = Invoice.query.count() + ExpenseClaim.query.count()
        elif d.code == 'HR':
            item_count = Resume.query.count() + EmployeeDocument.query.count()
        elif d.code == 'SALES':
            item_count = Lead.query.count() + ContractProposal.query.count()
        elif d.code == 'SUPPORT':
            item_count = SupportTicket.query.count() + FAQArticle.query.count()
        elif d.code == 'COMPLIANCE':
            item_count = HITLReview.query.count()
        else:
            item_count = 0
            
        stats[d.id] = {
            'members': member_count,
            'sub_depts': sub_dept_count,
            'items': item_count
        }
        
    return render_template(
        'admin/departments.html',
        departments=departments,
        stats=stats
    )

@departments_bp.route('/admin/audit-logs')
@admin_required
def admin_audit_logs():
    """Admin: Global Cross-Department Audit Trail."""
    logs = ActivityLog.query.order_by(ActivityLog.created_at.desc()).limit(150).all()
    departments = Department.query.all()
    
    return render_template(
        'departments/department_activity.html',
        logs=logs,
        user_department='Global (Admin View)',
        user_role='ADMIN',
        is_admin_view=True
    )
