from flask import Blueprint, render_template, request, redirect, url_for, flash, session, jsonify
from models.models import db, User
from utils.helpers import log_activity

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '').strip()
        
        user = User.query.filter(User.email.ilike(email)).first()
        if user and user.check_password(password):
            if not user.is_active:
                flash("This account is currently deactivated. Please contact your system administrator.", "danger")
                return render_template('login.html')

            session['user_id'] = user.id
            session['user_name'] = user.name
            session['email'] = user.email
            session['user_email'] = user.email
            session['role'] = (user.role or '').upper()
            session['department_id'] = user.department_id
            session['department_name'] = user.department_name
            session['department_code'] = user.department_code
            session['sub_department_id'] = user.sub_department_id
            session['sub_department_name'] = user.sub_department_name
            
            log_activity("User Login", "Auth", f"User {user.name} ({user.email}) logged in successfully as {user.role.upper()} ({user.department_name})", department_name=user.department_name)
            flash(f"Welcome back, {user.name}! ({user.department_name})", "success")
            
            next_url = request.args.get('next')
            return redirect(next_url or url_for('dashboard.index'))
        else:
            flash("Invalid email or password. Please try again.", "danger")
            
    return render_template('login.html')

@auth_bp.route('/quick-login/<role>')
def quick_login(role):
    """Allows one-click demo login for all 6 roles (Admin + 5 Departments)."""
    role = role.lower()
    role_email_map = {
        'admin': 'admin@smartbiz.local',
        'finance': 'finance@smartbiz.local',
        'sales': 'sales@smartbiz.local',
        'hr': 'hr@smartbiz.local',
        'support': 'support@smartbiz.local',
        'compliance': 'compliance@smartbiz.local'
    }
    
    email = role_email_map.get(role, 'admin@smartbiz.local')
    user = User.query.filter(User.email.ilike(email)).first()
    
    if not user:
        # Fallback to .ai email or role query
        fallback_email = email.replace('.local', '.ai')
        user = User.query.filter(User.email.ilike(fallback_email)).first()
        if not user:
            user = User.query.filter(User.role.ilike(role)).first()
        
    if user:
        if not user.is_active:
            flash("This account is deactivated.", "danger")
            return redirect(url_for('auth.login'))

        session['user_id'] = user.id
        session['user_name'] = user.name
        session['email'] = user.email
        session['user_email'] = user.email
        session['role'] = (user.role or '').upper()
        session['department_id'] = user.department_id
        session['department_name'] = user.department_name
        session['department_code'] = user.department_code
        session['sub_department_id'] = user.sub_department_id
        session['sub_department_name'] = user.sub_department_name
        
        log_activity("Quick Login", "Auth", f"Quick login as {user.name} ({user.role.upper()} – {user.department_name})", department_name=user.department_name)
        flash(f"Logged in as {user.name} ({user.department_name})", "info")
        return redirect(url_for('dashboard.index'))
    
    flash("Demo user not found. Please re-seed the database.", "warning")
    return redirect(url_for('auth.login'))

@auth_bp.route('/logout')
def logout():
    user_name = session.get('user_name', 'User')
    dept_name = session.get('department_name', 'Global')
    log_activity("User Logout", "Auth", f"User {user_name} logged out", department_name=dept_name)
    session.clear()
    flash("You have been securely logged out.", "info")
    return redirect(url_for('auth.login'))

