from flask import Blueprint, request, jsonify, session
from models.models import db, Invoice, Lead, Resume, SupportTicket, Notification, ActivityLog, ExpenseClaim, ContractProposal, EmployeeDocument
from utils.helpers import login_required, get_current_user

api_bp = Blueprint('api', __name__)

@api_bp.route('/api/search')
@login_required
def global_search():
    q = request.args.get('q', '').strip()
    if not q or len(q) < 2:
        return jsonify({'results': []})

    user = get_current_user()
    role = (user.role or '').upper() if user else 'GUEST'
    dept_code = (user.department_code or '').upper() if user else 'GUEST'

    results = []

    # Invoices (Finance or Admin)
    if role == 'ADMIN' or dept_code == 'FINANCE':
        invoices = Invoice.query.filter(
            (Invoice.invoice_number.ilike(f'%{q}%')) |
            (Invoice.vendor.ilike(f'%{q}%')) |
            (Invoice.customer_name.ilike(f'%{q}%'))
        ).limit(3).all()
        for inv in invoices:
            results.append({
                'type': 'Invoice',
                'title': f"Invoice #{inv.invoice_number or inv.id} - {inv.vendor}",
                'subtitle': f"${inv.total:,.2f} ({inv.status})",
                'link': f"/invoices/{inv.id}",
                'badge': inv.status
            })

    # Leads (Sales or Admin)
    if role == 'ADMIN' or dept_code == 'SALES':
        leads = Lead.query.filter(
            (Lead.name.ilike(f'%{q}%')) |
            (Lead.company.ilike(f'%{q}%')) |
            (Lead.email.ilike(f'%{q}%'))
        ).limit(3).all()
        for lead in leads:
            results.append({
                'type': 'Lead',
                'title': f"{lead.name} @ {lead.company}",
                'subtitle': f"Score: {lead.score}/100 ({lead.category})",
                'link': f"/leads",
                'badge': lead.category
            })

    # Resumes (HR or Admin)
    if role == 'ADMIN' or dept_code == 'HR':
        resumes = Resume.query.filter(
            (Resume.candidate_name.ilike(f'%{q}%')) |
            (Resume.skills.ilike(f'%{q}%'))
        ).limit(3).all()
        for res in resumes:
            results.append({
                'type': 'Resume',
                'title': f"{res.candidate_name}",
                'subtitle': f"Match: {res.match_score}% ({res.recommendation})",
                'link': f"/resumes",
                'badge': res.recommendation
            })

    # Support Tickets (Support or Admin)
    if role == 'ADMIN' or dept_code == 'SUPPORT':
        tickets = SupportTicket.query.filter(
            (SupportTicket.ticket_number.ilike(f'%{q}%')) |
            (SupportTicket.subject.ilike(f'%{q}%')) |
            (SupportTicket.customer_name.ilike(f'%{q}%'))
        ).limit(3).all()
        for t in tickets:
            results.append({
                'type': 'Ticket',
                'title': f"{t.ticket_number}: {t.subject}",
                'subtitle': f"[{t.priority}] {t.category} - {t.department}",
                'link': f"/support",
                'badge': t.priority
            })

    return jsonify({'results': results})

@api_bp.route('/api/notifications')
@login_required
def get_notifications():
    user = get_current_user()
    role = (user.role or '').upper() if user else 'ADMIN'
    dept_id = user.department_id if user else None

    if role == 'ADMIN':
        notifs = Notification.query.order_by(Notification.created_at.desc()).limit(15).all()
    else:
        notifs = Notification.query.filter(
            (Notification.role_target.in_(['ALL', role])) |
            (Notification.department_id == dept_id) |
            (Notification.user_id == session.get('user_id'))
        ).order_by(Notification.created_at.desc()).limit(10).all()

    unread_count = sum(1 for n in notifs if not n.is_read)
    return jsonify({
        'unread_count': unread_count,
        'notifications': [n.to_dict() for n in notifs]
    })

@api_bp.route('/api/notifications/mark-read', methods=['POST'])
@login_required
def mark_notifications_read():
    user = get_current_user()
    role = (user.role or '').upper() if user else 'ADMIN'
    dept_id = user.department_id if user else None

    if role == 'ADMIN':
        notifs = Notification.query.filter_by(is_read=False).all()
    else:
        notifs = Notification.query.filter(
            Notification.is_read == False,
            (Notification.role_target.in_(['ALL', role])) |
            (Notification.department_id == dept_id) |
            (Notification.user_id == session.get('user_id'))
        ).all()

    for n in notifs:
        n.is_read = True
    db.session.commit()
    return jsonify({'success': True})

