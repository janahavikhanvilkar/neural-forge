from functools import wraps
from flask import session, redirect, url_for, flash, request, jsonify, render_template
from models.models import db, ActivityLog, Notification, SystemSetting, User, Department, SubDepartment

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            if request.path.startswith('/api/') or request.is_json:
                return jsonify({'success': False, 'error': 'Authentication required'}), 401
            flash('Please log in to access this page.', 'warning')
            return redirect(url_for('auth.login', next=request.url))
        
        # Verify user is active
        user = User.query.get(session['user_id'])
        if not user or not user.is_active:
            session.clear()
            flash('Your account is inactive or disabled. Please contact the administrator.', 'danger')
            return redirect(url_for('auth.login'))
            
        return f(*args, **kwargs)
    return decorated_function

def department_required(allowed_departments):
    """
    Ensures that the logged-in user belongs to one of the allowed departments or is an ADMIN.
    Blocks unauthorized access at backend route and API level with HTTP 403.
    """
    if isinstance(allowed_departments, str):
        allowed_departments = [allowed_departments]
    
    # Normalize codes to upper case
    normalized_allowed = [d.upper().strip() for d in allowed_departments]

    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if 'user_id' not in session:
                if request.path.startswith('/api/') or request.is_json:
                    return jsonify({'success': False, 'error': 'Authentication required'}), 401
                flash('Please log in first.', 'warning')
                return redirect(url_for('auth.login', next=request.url))

            user = User.query.get(session.get('user_id'))
            if not user or not user.is_active:
                session.clear()
                flash('Your account has been deactivated.', 'danger')
                return redirect(url_for('auth.login'))

            user_role = (user.role or '').upper().strip()
            user_dept_code = (user.department_code or '').upper().strip()

            # ADMIN has unrestricted access to everything
            if user_role == 'ADMIN':
                return f(*args, **kwargs)

            # Check if user's role or department code matches any allowed department
            is_authorized = (
                user_role in normalized_allowed or
                user_dept_code in normalized_allowed or
                any(d in user.department_name.upper() for d in normalized_allowed)
            )

            if not is_authorized:
                if request.path.startswith('/api/') or request.is_json:
                    return jsonify({
                        'success': False,
                        'error': f'Access Denied: Requires one of {normalized_allowed} department access.',
                        'user_department': user.department_name,
                        'code': 403
                    }), 403
                
                return render_template(
                    'access_denied.html',
                    required_departments=normalized_allowed,
                    user_department=user.department_name,
                    user_role=user.role
                ), 403

            return f(*args, **kwargs)
        return decorated_function
    return decorator

def admin_required(f):
    """Restricts route strictly to system administrators."""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            if request.path.startswith('/api/') or request.is_json:
                return jsonify({'success': False, 'error': 'Authentication required'}), 401
            flash('Please log in first.', 'warning')
            return redirect(url_for('auth.login', next=request.url))

        user = User.query.get(session.get('user_id'))
        if not user or (user.role or '').upper() != 'ADMIN':
            if request.path.startswith('/api/') or request.is_json:
                return jsonify({'success': False, 'error': 'Admin privileges required', 'code': 403}), 403
            return render_template(
                'access_denied.html',
                required_departments=['ADMIN'],
                user_department=user.department_name if user else 'Unknown',
                user_role=user.role if user else 'Unknown'
            ), 403
            
        return f(*args, **kwargs)
    return decorated_function

def role_required(allowed_roles):
    """Alias for role-based authorization."""
    return department_required(allowed_roles)

def get_current_user():
    user_id = session.get('user_id')
    if user_id:
        return User.query.get(user_id)
    return None

def get_user_department_code():
    user = get_current_user()
    if user:
        return user.department_code
    return 'GUEST'

def log_activity(action: str, module: str, description: str, status: str = "Success", department_name: str = None, task_id: int = None):
    """Records an audit event in the centralized ActivityLog table with department metadata."""
    try:
        from flask import has_request_context
        user_id = None
        user_name = "System"
        role = "SYSTEM"
        ip_addr = "127.0.0.1"
        dept_id = None
        sub_dept_id = None
        dept_name = department_name or "Global"

        if has_request_context():
            user_id = session.get('user_id')
            user_name = session.get('user_name', 'System')
            role = session.get('role', 'SYSTEM').upper()
            dept_id = session.get('department_id')
            sub_dept_id = session.get('sub_department_id')
            if not department_name:
                dept_name = session.get('department_name', 'Global')
            ip_addr = request.remote_addr or '127.0.0.1'
        
        log_entry = ActivityLog(
            user_id=user_id,
            user_name=user_name,
            role=role,
            department_id=dept_id,
            sub_department_id=sub_dept_id,
            department_name=dept_name,
            task_id=task_id,
            action=action,
            module=module,
            description=description,
            status=status,
            ip_address=ip_addr
        )
        db.session.add(log_entry)
        db.session.commit()
    except Exception as e:
        db.session.rollback()
        print(f"Failed to log activity: {e}")

def create_notification(title: str, message: str, module: str = "System", role_target: str = "ALL", department_id: int = None, link: str = None):
    """Dispatches a department-isolated notification."""
    try:
        notif = Notification(
            title=title,
            message=message,
            module=module,
            role_target=role_target.upper(),
            department_id=department_id,
            link=link or '#',
            is_read=False
        )
        db.session.add(notif)
        db.session.commit()
    except Exception as e:
        db.session.rollback()
        print(f"Failed to create notification: {e}")

def get_system_thresholds():
    """Retrieves current confidence thresholds from DB or defaults."""
    auto_thresh = 80
    review_thresh = 60
    try:
        s_auto = SystemSetting.query.filter_by(key='AUTO_PROCESS_THRESHOLD').first()
        s_review = SystemSetting.query.filter_by(key='HITL_REVIEW_THRESHOLD').first()
        if s_auto:
            auto_thresh = int(s_auto.value)
        if s_review:
            review_thresh = int(s_review.value)
    except Exception:
        pass
    return auto_thresh, review_thresh

