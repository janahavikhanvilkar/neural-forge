document.addEventListener('DOMContentLoaded', function () {
    // 1. Sidebar Toggle on Mobile
    const sidebar = document.getElementById('appSidebar');
    const toggleBtn = document.getElementById('sidebarToggleBtn');
    const closeBtn = document.getElementById('sidebarCloseBtn');

    if (toggleBtn && sidebar) {
        toggleBtn.addEventListener('click', () => sidebar.classList.toggle('show'));
    }
    if (closeBtn && sidebar) {
        closeBtn.addEventListener('click', () => sidebar.classList.remove('show'));
    }

    // 2. Global Search Auto-complete
    const searchInput = document.getElementById('globalSearchInput');
    const searchDropdown = document.getElementById('searchResultsDropdown');
    const searchResultsList = document.getElementById('searchResultsList');

    if (searchInput) {
        // Keyboard shortcut: Press '/' to focus search
        document.addEventListener('keydown', function(e) {
            if (e.key === '/' && document.activeElement !== searchInput && !['INPUT', 'TEXTAREA'].includes(document.activeElement.tagName)) {
                e.preventDefault();
                searchInput.focus();
            }
        });

        let debounceTimer;
        searchInput.addEventListener('input', function () {
            clearTimeout(debounceTimer);
            const query = this.value.trim();

            if (query.length < 2) {
                searchDropdown.classList.add('d-none');
                return;
            }

            debounceTimer = setTimeout(() => {
                fetch(`/api/search?q=${encodeURIComponent(query)}`)
                    .then(res => res.json())
                    .then(data => {
                        if (data.results && data.results.length > 0) {
                            searchResultsList.innerHTML = data.results.map(item => `
                                <a href="${item.link}" class="d-flex align-items-center justify-content-between p-2 text-decoration-none text-dark hover-bg-light rounded-2 small">
                                    <div>
                                        <span class="badge bg-secondary-subtle text-secondary me-1" style="font-size: 0.65rem;">${item.type}</span>
                                        <strong>${item.title}</strong>
                                        <div class="text-muted" style="font-size: 0.75rem;">${item.subtitle}</div>
                                    </div>
                                    <span class="badge bg-light text-dark border">${item.badge}</span>
                                </a>
                            `).join('');
                            searchDropdown.classList.remove('d-none');
                        } else {
                            searchResultsList.innerHTML = '<div class="p-2 text-muted small text-center">No matching records found.</div>';
                            searchDropdown.classList.remove('d-none');
                        }
                    })
                    .catch(() => {
                        searchDropdown.classList.add('d-none');
                    });
            }, 250);
        });

        // Hide search on click outside
        document.addEventListener('click', function (e) {
            if (!searchInput.contains(e.target) && !searchDropdown.contains(e.target)) {
                searchDropdown.classList.add('d-none');
            }
        });
    }

    // 3. Live Notifications Engine
    const notifBtn = document.getElementById('notificationsBtn');
    const notifBadge = document.getElementById('notifBadge');
    const notifList = document.getElementById('notifList');
    const markAllReadBtn = document.getElementById('markAllReadBtn');

    function loadNotifications() {
        if (!notifList) return;
        fetch('/api/notifications')
            .then(res => res.json())
            .then(data => {
                if (data.unread_count > 0) {
                    notifBadge.innerText = data.unread_count;
                    notifBadge.style.display = 'inline-block';
                } else {
                    notifBadge.style.display = 'none';
                }

                if (data.notifications && data.notifications.length > 0) {
                    notifList.innerHTML = data.notifications.map(n => `
                        <a href="${n.link}" class="d-block p-3 border-bottom text-decoration-none text-dark ${!n.is_read ? 'bg-light' : ''} hover-bg-light">
                            <div class="d-flex align-items-center justify-content-between mb-1">
                                <strong class="small text-dark">${n.title}</strong>
                                <span class="badge bg-secondary-subtle text-secondary" style="font-size: 0.65rem;">${n.module}</span>
                            </div>
                            <div class="text-muted small">${n.message}</div>
                            <div class="text-muted font-monospace mt-1" style="font-size: 0.65rem;">${n.created_at}</div>
                        </a>
                    `).join('');
                } else {
                    notifList.innerHTML = '<div class="p-3 text-center text-muted small">No notifications yet.</div>';
                }
            })
            .catch(() => {});
    }

    if (notifBtn) {
        loadNotifications();
        // Periodic check every 30 seconds
        setInterval(loadNotifications, 30000);
    }

    if (markAllReadBtn) {
        markAllReadBtn.addEventListener('click', function () {
            fetch('/api/notifications/mark-read', { method: 'POST' })
                .then(() => {
                    notifBadge.style.display = 'none';
                    loadNotifications();
                });
        });
    }

    // =========================================================================
    // 4. GOOGLE GEMINI AI COPILOT CLIENT (DOCUMENT-AWARE)
    // =========================================================================
    const aiDrawer = document.getElementById('smartbizAiDrawer');
    const aiInput = document.getElementById('smartbizAiInput');
    const aiSendBtn = document.getElementById('smartbizAiSendBtn');
    const aiMessages = document.getElementById('smartbizAiMessages');
    const copilotDocContext = document.getElementById('copilotDocContext');
    const attachedDocPill = document.getElementById('attachedDocPill');
    const attachedDocName = document.getElementById('attachedDocName');
    const copilotModelInfo = document.getElementById('copilotModelInfo');

    let attachedDoc = null;
    let copilotHistory = [];

    window.toggleSmartBizAiDrawer = function () {
        if (!aiDrawer) return;
        const isHidden = aiDrawer.classList.contains('hidden');
        if (isHidden) {
            aiDrawer.classList.remove('hidden');
            loadCopilotDocuments();
            if (aiInput) setTimeout(() => aiInput.focus(), 150);
        } else {
            aiDrawer.classList.add('hidden');
        }
    };

    window.clearCopilotChat = function () {
        if (!aiMessages) return;
        copilotHistory = [];
        attachedDoc = null;
        if (attachedDocPill) attachedDocPill.classList.add('d-none');
        aiMessages.innerHTML = `
            <div class="smartbiz-ai-msg assistant">
                <div class="user-avatar-circle text-white rounded-circle d-flex align-items-center justify-content-center" style="width: 28px; height: 28px; background: linear-gradient(135deg, #4f46e5, #0ea5e9); font-size: 0.75rem; flex-shrink: 0;">
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="white">
                        <path d="M12 0C12 6.627 6.627 12 0 12C6.627 12 12 17.373 12 24C12 17.373 17.373 12 24 12C17.373 12 12 6.627 12 0Z"/>
                    </svg>
                </div>
                <div>
                    <div class="smartbiz-ai-bubble">
                        👋 Hello! I am your SmartBiz AI Copilot, powered by Google Gemini. I can help summarize uploaded documents, analyze invoices and resumes, answer questions about your uploaded files, and assist with your SmartBiz workflows.
                    </div>
                    <div class="smartbiz-ai-quick-pills">
                        <button type="button" class="smartbiz-ai-quick-pill" onclick="useAiSuggestion(this)">📊 Which invoice has the highest total?</button>
                        <button type="button" class="smartbiz-ai-quick-pill" onclick="useAiSuggestion(this)">⚖️ Audit invoice math & GST calculations</button>
                        <button type="button" class="smartbiz-ai-quick-pill" onclick="useAiSuggestion(this)">📄 Summarize this document</button>
                        <button type="button" class="smartbiz-ai-quick-pill" onclick="useAiSuggestion(this)">🏆 Who is the strongest candidate?</button>
                        <button type="button" class="smartbiz-ai-quick-pill" onclick="useAiSuggestion(this)">📝 Draft a polite payment reminder</button>
                    </div>
                </div>
            </div>
        `;
    };

    window.loadCopilotDocuments = function () {
        if (!copilotDocContext) return;
        fetch('/api/copilot/documents')
            .then(res => res.json())
            .then(data => {
                if (!data.documents) return;
                // Preserve the 4 standard options
                const defaultOpts = [
                    '<option value="auto">Auto (Current Page / File)</option>',
                    '<option value="all_invoices">All Invoices (Cross-Audit)</option>',
                    '<option value="all_resumes">All Resumes (Candidates)</option>',
                    '<option value="none">None (General Copilot)</option>'
                ];
                const currentVal = copilotDocContext.value;

                let invoicesHtml = data.documents.filter(d => d.type === 'invoice').map(d => `<option value="${d.id}">${escapeHtml(d.label)}</option>`).join('');
                let resumesHtml = data.documents.filter(d => d.type === 'resume').map(d => `<option value="${d.id}">${escapeHtml(d.label)}</option>`).join('');

                let fullHtml = defaultOpts.join('');
                if (invoicesHtml) fullHtml += `<optgroup label="Uploaded Invoices">${invoicesHtml}</optgroup>`;
                if (resumesHtml) fullHtml += `<optgroup label="Screened Resumes">${resumesHtml}</optgroup>`;

                copilotDocContext.innerHTML = fullHtml;
                if (currentVal) copilotDocContext.value = currentVal;
            })
            .catch(() => {});
    };

    window.handleCopilotFileUpload = function (input) {
        if (!input.files || !input.files[0]) return;
        const file = input.files[0];

        const formData = new FormData();
        formData.append('file', file);

        // Show uploading notification inside chat
        const loadingMsg = document.createElement('div');
        loadingMsg.className = 'smartbiz-ai-msg assistant';
        loadingMsg.id = 'copilot-uploading-msg';
        loadingMsg.innerHTML = `
            <div class="user-avatar-circle bg-primary text-white rounded-circle d-flex align-items-center justify-content-center" style="width: 28px; height: 28px; font-size: 0.75rem; flex-shrink: 0;">
                <i class="bi bi-paperclip"></i>
            </div>
            <div class="smartbiz-ai-bubble text-muted">
                <i class="bi bi-arrow-repeat animate-spin me-1"></i> Uploading and extracting <strong>${escapeHtml(file.name)}</strong>...
            </div>
        `;
        aiMessages.appendChild(loadingMsg);
        aiMessages.scrollTop = aiMessages.scrollHeight;

        fetch('/api/copilot/upload', {
            method: 'POST',
            body: formData
        })
        .then(res => res.json())
        .then(data => {
            const upElem = document.getElementById('copilot-uploading-msg');
            if (upElem) upElem.remove();

            if (data.success) {
                attachedDoc = { name: data.name, text: data.text, path: data.path };
                if (attachedDocPill && attachedDocName) {
                    attachedDocName.innerText = data.name;
                    attachedDocPill.classList.remove('d-none');
                    attachedDocPill.classList.add('d-inline-flex');
                }

                const successMsg = document.createElement('div');
                successMsg.className = 'smartbiz-ai-msg assistant';
                successMsg.innerHTML = `
                    <div class="user-avatar-circle bg-success text-white rounded-circle d-flex align-items-center justify-content-center" style="width: 28px; height: 28px; font-size: 0.75rem; flex-shrink: 0;">
                        <i class="bi bi-check-lg"></i>
                    </div>
                    <div>
                        <div class="smartbiz-ai-bubble">
                            📎 Document attached: <strong>${escapeHtml(data.name)}</strong>
                            <br><small class="text-muted">You can now ask questions about this document, audit it, or summarize it.</small>
                        </div>
                    </div>
                `;
                aiMessages.appendChild(successMsg);
                aiMessages.scrollTop = aiMessages.scrollHeight;
            } else {
                alert(data.error || 'Failed to parse document.');
            }
        })
        .catch(() => {
            const upElem = document.getElementById('copilot-uploading-msg');
            if (upElem) upElem.remove();
            alert('Error uploading document to Copilot.');
        })
        .finally(() => {
            input.value = '';
        });
    };

    window.removeAttachedDoc = function () {
        attachedDoc = null;
        if (attachedDocPill) {
            attachedDocPill.classList.add('d-none');
            attachedDocPill.classList.remove('d-inline-flex');
        }
    };

    window.openCopilotWithDocument = function (type, id, label) {
        window.toggleSmartBizAiDrawer();
        if (copilotDocContext) {
            copilotDocContext.value = `${type}_${id}`;
        }
        if (aiInput) {
            aiInput.value = `Summarize and explain ${label} and verify all key details.`;
            window.sendSmartBizAiMessage();
        }
    };

    window.useAiSuggestion = function (btn) {
        const text = btn.innerText.replace(/^[✨💡📊💼📝⚖️📄🏆]\s*/, '').trim();
        if (aiInput) {
            aiInput.value = text;
            window.sendSmartBizAiMessage();
        }
    };

    function escapeHtml(text) {
        const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' };
        return String(text).replace(/[&<>"']/g, m => map[m]);
    }

    function formatAiText(text) {
        if (!text) return '';
        let clean = escapeHtml(text);
        // Bold: **text**
        clean = clean.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
        // Italic: *text*
        clean = clean.replace(/\*(.*?)\*/g, '<em>$1</em>');
        // Bullet points
        clean = clean.replace(/^\s*[-•]\s+(.*)$/gm, '<li class="ms-3">$1</li>');
        // Inline code
        clean = clean.replace(/`([^`]+)`/g, '<code class="bg-light px-1 py-0.5 rounded text-dark font-monospace">$1</code>');
        // Line breaks
        clean = clean.replace(/\n/g, '<br>');
        return clean;
    }

    window.sendSmartBizAiMessage = function () {
        if (!aiInput || !aiMessages) return;
        const text = aiInput.value.trim();
        if (!text) return;

        // Append User Message
        const userMsg = document.createElement('div');
        userMsg.className = 'smartbiz-ai-msg user';
        userMsg.innerHTML = `<div class="smartbiz-ai-bubble">${escapeHtml(text)}</div>`;
        aiMessages.appendChild(userMsg);
        aiInput.value = '';

        copilotHistory.push({ sender: 'User', text: text });

        // Disable send button and add typing indicator
        if (aiSendBtn) aiSendBtn.disabled = true;
        const typingId = 'typing-' + Date.now();
        const typingMsg = document.createElement('div');
        typingMsg.className = 'smartbiz-ai-msg assistant';
        typingMsg.id = typingId;
        typingMsg.innerHTML = `
            <div class="user-avatar-circle text-white rounded-circle d-flex align-items-center justify-content-center" style="width: 28px; height: 28px; background: linear-gradient(135deg, #4f46e5, #0ea5e9); font-size: 0.75rem; flex-shrink: 0;">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="white">
                    <path d="M12 0C12 6.627 6.627 12 0 12C6.627 12 12 17.373 12 24C12 17.373 17.373 12 24 12C17.373 12 12 6.627 12 0Z"/>
                </svg>
            </div>
            <div class="smartbiz-ai-bubble text-muted">
                <span class="typing-dots me-2">
                    <span class="typing-dot"></span>
                    <span class="typing-dot"></span>
                    <span class="typing-dot"></span>
                </span>
                <span style="font-size: 0.78rem;">Thinking with Google Gemini...</span>
            </div>
        `;
        aiMessages.appendChild(typingMsg);
        aiMessages.scrollTop = aiMessages.scrollHeight;

        const pageContext = {
            path: window.location.pathname,
            title: document.title
        };

        const docContextVal = copilotDocContext ? copilotDocContext.value : 'auto';

        const payload = {
            message: text,
            context: pageContext,
            document_context: docContextVal,
            doc_text: attachedDoc ? attachedDoc.text : null,
            doc_name: attachedDoc ? attachedDoc.name : null,
            history: copilotHistory.slice(-6)
        };

        fetch('/api/assistant/chat', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        })
        .then(res => res.json())
        .then(data => {
            const typingElem = document.getElementById(typingId);
            if (typingElem) typingElem.remove();

            const assistantMsg = document.createElement('div');
            assistantMsg.className = 'smartbiz-ai-msg assistant';
            const textToFormat = data.reply || data.message || data.error || 'No response received from Gemini.';
            const formatted = formatAiText(textToFormat);

            let sourcesHtml = '';
            if (data.sources && data.sources.length > 0) {
                const badgeItems = data.sources.map(s => `<span class="badge bg-light text-dark border px-1.5 py-0.5 me-1"><i class="bi bi-file-earmark-check text-primary me-1"></i>${escapeHtml(s)}</span>`).join('');
                sourcesHtml = `<div class="mt-2 pt-1 border-top" style="font-size: 0.7rem;"><span class="text-muted fw-semibold me-1">Sources:</span>${badgeItems}</div>`;
            }

            assistantMsg.innerHTML = `
                <div class="user-avatar-circle text-white rounded-circle d-flex align-items-center justify-content-center" style="width: 28px; height: 28px; background: linear-gradient(135deg, #4f46e5, #0ea5e9); font-size: 0.75rem; flex-shrink: 0;">
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="white">
                        <path d="M12 0C12 6.627 6.627 12 0 12C6.627 12 12 17.373 12 24C12 17.373 17.373 12 24 12C17.373 12 12 6.627 12 0Z"/>
                    </svg>
                </div>
                <div style="max-width: 85%;">
                    <div class="smartbiz-ai-bubble">${formatted}${sourcesHtml}</div>
                    <div class="text-muted d-flex align-items-center gap-1 mt-1 ms-1" style="font-size: 0.68rem;">
                        <span>Google Gemini &bull; ${escapeHtml(data.model || 'Gemini')}</span>
                    </div>
                </div>
            `;
            aiMessages.appendChild(assistantMsg);
            aiMessages.scrollTop = aiMessages.scrollHeight;

            copilotHistory.push({ sender: 'Assistant', text: textToFormat });

            if (copilotModelInfo && data.model) {
                copilotModelInfo.innerText = data.model;
            }
        })
        .catch(err => {
            const typingElem = document.getElementById(typingId);
            if (typingElem) typingElem.remove();

            const errMsg = document.createElement('div');
            errMsg.className = 'smartbiz-ai-msg assistant';
            errMsg.innerHTML = `
                <div class="smartbiz-ai-bubble text-danger border-danger-subtle bg-danger-subtle">
                    <i class="bi bi-exclamation-circle me-1"></i>
                    Unable to communicate with Google Gemini. Please check the Gemini API configuration.
                </div>
            `;
            aiMessages.appendChild(errMsg);
            aiMessages.scrollTop = aiMessages.scrollHeight;
        })
        .finally(() => {
            if (aiSendBtn) aiSendBtn.disabled = false;
        });
    };

    if (aiInput) {
        aiInput.addEventListener('keydown', function (e) {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                window.sendSmartBizAiMessage();
            }
        });
    }
});
