import os
import re
import json
import requests
from pathlib import Path
from config import Config
from utils.file_parser import extract_text_from_file, clean_extracted_text


class AIService:
    """
    Centralized AI Service for SmartBiz powered by Google Gemini API.
    Handles:
    - Document reading and multimodal text processing
    - Invoice data extraction with full Indian GST / TCS / Line Item support
    - Programmatic invoice math & structure validation
    - Multi-invoice batch processing & duplicate auditing
    - Resume screening, skill matching, and multi-candidate comparative ranking
    - Single & multi-document summarization
    - Centralized Document-Aware AI Copilot with source attribution
    - Lead scoring, Support ticket classification & response generation
    """

    def __init__(self):
        self.api_key = (os.getenv("GEMINI_API_KEY") or getattr(Config, "GEMINI_API_KEY", "")).strip()
        self.primary_model = os.getenv("GEMINI_MODEL") or getattr(Config, "GEMINI_MODEL", "gemini-3.7-flash")
        self.candidate_models = [
            self.primary_model,
            "gemini-3.7-flash",
            "gemini-3.5-flash",
            "gemini-3.6-flash",
            "gemini-3.1-flash-lite",
            "gemini-flash-latest"
        ]
        # Remove duplicate models while preserving preference order
        seen = set()
        self.models_to_try = [m for m in self.candidate_models if not (m in seen or seen.add(m))]

        # Backwards compatibility attributes
        self.ollama_base_url = os.getenv("OLLAMA_BASE_URL") or getattr(Config, "OLLAMA_BASE_URL", "http://localhost:11434")
        self.ollama_model = os.getenv("OLLAMA_MODEL") or getattr(Config, "OLLAMA_MODEL", "qwen3:8b")
        self.ai_provider = "gemini"

        self.client = None
        self._init_client()

    def _init_client(self):
        """Initializes the official Google GenAI SDK Client."""
        if self.api_key:
            try:
                from google import genai
                self.client = genai.Client(api_key=self.api_key)
            except Exception as e:
                print(f"Warning: Google GenAI Client initialization failed: {e}")
                self.client = None

    # =========================================================================
    # CORE GEMINI API EXECUTION ENGINE
    # =========================================================================

    def call_gemini(
        self,
        prompt: str,
        system_instruction: str = None,
        json_format: bool = True,
        temperature: float = 0.1,
        preferred_model: str = None
    ) -> str:
        """
        Executes a prompt against the Google Gemini API.
        Attempts primary model with automatic fallback across candidate models
        and REST API fallback in case of transient 503/429 spikes.
        """
        if not self.api_key:
            return None

        models = [preferred_model] if preferred_model else self.models_to_try

        # 1. Official Google GenAI SDK Call
        if self.client:
            for model_name in models:
                if not model_name:
                    continue
                try:
                    config = {
                        "temperature": temperature,
                        "top_p": 0.8,
                    }
                    if system_instruction:
                        config["system_instruction"] = system_instruction
                    if json_format:
                        config["response_mime_type"] = "application/json"

                    response = self.client.models.generate_content(
                        model=model_name,
                        contents=prompt,
                        config=config
                    )
                    if response and response.text:
                        return response.text.strip()
                except Exception as e:
                    # Retry next candidate model on transient API spikes
                    err_msg = str(e)
                    if any(code in err_msg for code in ["503", "429", "404", "UNAVAILABLE"]):
                        continue
                    else:
                        print(f"Gemini SDK call error on {model_name}: {e}")

        # 2. REST API Fallback
        for model_name in models:
            if not model_name:
                continue
            try:
                clean_model = model_name.replace("models/", "")
                url = f"https://generativelanguage.googleapis.com/v1beta/models/{clean_model}:generateContent?key={self.api_key}"
                headers = {"Content-Type": "application/json"}

                final_prompt = prompt
                if system_instruction:
                    final_prompt = f"SYSTEM INSTRUCTION:\n{system_instruction}\n\nUSER REQUEST:\n{prompt}"

                gen_config = {"temperature": temperature, "topP": 0.8}
                if json_format:
                    gen_config["responseMimeType"] = "application/json"

                payload = {
                    "contents": [{"parts": [{"text": final_prompt}]}],
                    "generationConfig": gen_config
                }
                resp = requests.post(url, headers=headers, json=payload, timeout=40)
                if resp.status_code == 200:
                    data = resp.json()
                    candidates = data.get("candidates", [])
                    if candidates:
                        parts = candidates[0].get("content", {}).get("parts", [])
                        if parts:
                            return parts[0].get("text", "").strip()
            except Exception:
                continue

        return None

    # =========================================================================
    # ROBUST JSON RESPONSE PARSING
    # =========================================================================

    def _clean_json_response(self, text: str):
        """
        Parses JSON from Gemini responses, handling markdown code blocks,
        unquoted numbers, currency prefixes, and trailing commas.
        """
        if not text:
            return {}

        clean_text = text.strip()
        # Remove markdown code blocks if present
        if "```" in clean_text:
            match = re.search(r"```(?:json)?\s*([\s\S]*?)\s*```", clean_text)
            if match:
                clean_text = match.group(1).strip()

        # Try direct JSON parsing
        try:
            return json.loads(clean_text)
        except Exception:
            pass

        # Attempt to isolate outer braces or brackets
        try:
            start_brace = clean_text.find('{')
            end_brace = clean_text.rfind('}')
            if start_brace != -1 and end_brace != -1:
                sub = clean_text[start_brace:end_brace + 1]
                # Fix trailing commas before closing braces
                sub = re.sub(r",\s*([}\]])", r"\1", sub)
                return json.loads(sub)
        except Exception:
            pass

        try:
            start_bracket = clean_text.find('[')
            end_bracket = clean_text.rfind(']')
            if start_bracket != -1 and end_bracket != -1:
                sub = clean_text[start_bracket:end_bracket + 1]
                sub = re.sub(r",\s*([}\]])", r"\1", sub)
                return json.loads(sub)
        except Exception:
            pass

        return {}

    def _normalize_money(self, val) -> float:
        """Converts strings like '₹5,544,900.00' or 5544900 to clean float."""
        if val is None or val == "":
            return None
        if isinstance(val, (int, float)):
            return round(float(val), 2)
        try:
            cleaned = str(val).replace(",", "").replace("₹", "").replace("$", "").replace("€", "").replace("£", "").strip()
            match = re.search(r"[-+]?\d*\.?\d+", cleaned)
            if match:
                return round(float(match.group(0)), 2)
        except Exception:
            pass
        return None

    # =========================================================================
    # DOCUMENT TEXT EXTRACTION & HANDLING
    # =========================================================================

    def extract_document_text(self, file_path: str) -> str:
        """Extracts text content from PDF, DOCX, TXT, or Image file."""
        return clean_extracted_text(extract_text_from_file(file_path))

    # =========================================================================
    # 1. INVOICE AI: EXTRACTION, GST AWARENESS & PROGRAMMATIC AUDITING
    # =========================================================================

    def extract_invoice_data(self, raw_text: str, filename: str = "") -> dict:
        """
        Extracts structured invoice information using Google Gemini.
        Accurately handles:
        - Vendor name & Customer / Bill To
        - Invoice number, dates (invoice date, due date)
        - Currency
        - Subtotal (Total Before Tax / Taxable Value)
        - Full Indian GST breakdown (CGST, SGST, IGST, Total GST) & TCS
        - Final Total Amount Due
        - Line items with quantity, unit price, amount, and HSN/SAC
        - Payment information / terms
        - Never hallucinates or uses fake defaults.
        """
        if not raw_text or not raw_text.strip():
            return {
                "vendor": "Unknown Vendor",
                "customer_name": "Not found",
                "invoice_number": "",
                "invoice_date": "",
                "due_date": "",
                "currency": "USD",
                "subtotal": 0.0,
                "tax": 0.0,
                "cgst": None,
                "sgst": None,
                "igst": None,
                "tcs": None,
                "total": 0.0,
                "payment_info": "Not found",
                "line_items": [],
                "validation_flags": ["Empty document: no text could be extracted."],
                "confidence": 0,
                "reasoning": "Document contained no extractable text."
            }

        prompt = f"""You are an expert financial auditor and automated invoice parser.
Extract structured invoice data from the document text below into strict JSON format.

CRITICAL ACCURACY & GROUNDING RULES:
1. Extract values strictly based on the text. NEVER invent, hallucinate, or guess values.
2. If a field is not present in the document, return null or "Not found".
3. VENDOR / SELLER: The business or party issuing the invoice. NEVER use monetary amounts or generic terms like 'Invoice' or 'Subtotal'.
4. CUSTOMER / BUYER: Found under 'Bill To', 'Client', 'Buyer', or 'Details of Customer'.
5. FINANCIAL FIELDS & INDIAN GST HANDLING:
   - "subtotal": Total Amount Before Tax / Taxable Value.
   - "tax": Total tax / GST / Sales Tax / VAT.
   - "cgst": Central GST if specifically listed, else null.
   - "sgst": State GST if specifically listed, else null.
   - "igst": Integrated GST if specifically listed, else null.
   - "tcs": Tax Collected at Source if specifically listed, else null.
   - "total": The final total amount due / grand total payable.
   - IMPORTANT: In invoices with Total Amount Before Tax and Total Amount, do NOT confuse them. Do NOT map the final total into subtotal!
6. LINE ITEMS:
   Extract all line item rows with description, quantity, unit_price, amount, and hsn_sac (if available).
7. PAYMENT INFORMATION:
   Extract payment method (NEFT, Wire, Bank Transfer, Card, UPI, etc.), account details, or terms.

DOCUMENT FILENAME: {filename}

INVOICE TEXT:
{raw_text[:15000]}

OUTPUT STRICT JSON FORMAT:
{{
    "vendor": "string",
    "customer_name": "string",
    "invoice_number": "string",
    "invoice_date": "string",
    "due_date": "string",
    "currency": "string (USD, INR, EUR, GBP, etc.)",
    "subtotal": float or null,
    "tax": float or null,
    "cgst": float or null,
    "sgst": float or null,
    "igst": float or null,
    "tcs": float or null,
    "total": float or null,
    "payment_info": "string",
    "line_items": [
        {{
            "description": "string",
            "quantity": float or null,
            "unit_price": float or null,
            "amount": float or null,
            "hsn_sac": "string or null"
        }}
    ],
    "validation_flags": [],
    "confidence": integer (0 to 100),
    "reasoning": "string"
}}"""

        response_text = self.call_gemini(
            prompt,
            system_instruction="You are a high-accuracy invoice OCR and financial extraction engine. Extract only facts present in the text.",
            json_format=True
        )

        extracted = self._clean_json_response(response_text)

        if not extracted or not isinstance(extracted, dict):
            extracted = self._grounded_heuristic_invoice_extraction(raw_text, filename)

        # Normalize financial values
        extracted["subtotal"] = self._normalize_money(extracted.get("subtotal"))
        extracted["tax"] = self._normalize_money(extracted.get("tax"))
        extracted["total"] = self._normalize_money(extracted.get("total"))
        extracted["cgst"] = self._normalize_money(extracted.get("cgst"))
        extracted["sgst"] = self._normalize_money(extracted.get("sgst"))
        extracted["igst"] = self._normalize_money(extracted.get("igst"))
        extracted["tcs"] = self._normalize_money(extracted.get("tcs"))

        if not extracted.get("currency"):
            extracted["currency"] = "INR" if ("₹" in raw_text or "INR" in raw_text or "GST" in raw_text) else "USD"

        # Programmatic Validation
        extracted = self.validate_invoice(extracted, raw_text)

        return extracted

    def validate_invoice(self, extracted: dict, raw_text: str = "") -> dict:
        """
        Performs programmatic validation of invoice components.
        Checks for missing essential fields and performs component arithmetic checks
        accounting for discounts, GST/TCS, and rounding tolerances.
        """
        flags = extracted.get("validation_flags", [])
        if not isinstance(flags, list):
            flags = []

        vendor = str(extracted.get("vendor", "")).strip()
        inv_num = str(extracted.get("invoice_number", "")).strip()
        inv_date = str(extracted.get("invoice_date", "")).strip()
        customer = str(extracted.get("customer_name", "")).strip()
        due_date = str(extracted.get("due_date", "")).strip()

        subtotal = extracted.get("subtotal")
        tax = extracted.get("tax")
        total = extracted.get("total")
        cgst = extracted.get("cgst")
        sgst = extracted.get("sgst")
        igst = extracted.get("igst")
        tcs = extracted.get("tcs")

        # 1. Essential Field Auditing
        if not vendor or vendor.lower() in ["unknown vendor", "not found", "null", "none"]:
            flags.append("Vendor name could not be reliably identified")
        if not inv_num or inv_num.lower() in ["not found", "null", "none", "invoice"]:
            flags.append("Invoice number not found")
        if not inv_date or inv_date.lower() in ["not found", "null", "none"]:
            flags.append("Invoice date not found")
        if not customer or customer.lower() in ["not found", "null", "none"]:
            flags.append("Customer/Bill To not found")
        if not due_date or due_date.lower() in ["not found", "null", "none"]:
            flags.append("Due date not found")

        # 2. Mathematical Component Auditing
        if total is None or total <= 0:
            flags.append("Total amount could not be verified from document")
            confidence = min(int(extracted.get("confidence", 70)), 50)
        else:
            confidence = int(extracted.get("confidence", 90))
            math_verified = False

            # Check Standard subtotal + tax = total
            if subtotal is not None and tax is not None:
                expected = round(subtotal + tax, 2)
                if abs(expected - total) <= 0.08:
                    math_verified = True

            # Check GST + TCS components (subtotal + cgst + sgst + igst + tcs)
            if not math_verified and subtotal is not None:
                gst_sum = (cgst or 0.0) + (sgst or 0.0) + (igst or 0.0)
                if gst_sum > 0:
                    expected_with_tcs = round(subtotal + gst_sum + (tcs or 0.0), 2)
                    if abs(expected_with_tcs - total) <= 0.10:
                        math_verified = True

            # Check Line Items sum vs subtotal or total
            line_items = extracted.get("line_items", [])
            if line_items:
                item_amounts = [self._normalize_money(item.get("amount")) for item in line_items if self._normalize_money(item.get("amount")) is not None]
                if item_amounts:
                    items_total = round(sum(item_amounts), 2)
                    if subtotal is not None and abs(items_total - subtotal) <= 0.08:
                        math_verified = True
                    elif abs(items_total - total) <= 0.08:
                        math_verified = True

            if not math_verified and subtotal is not None and tax is not None and (subtotal > 0 or tax > 0):
                expected_std = round((subtotal or 0.0) + (tax or 0.0), 2)
                if abs(expected_std - total) > 0.10:
                    flags.append(f"Tax calculation mismatch: Components ({subtotal} + {tax}) do not sum to total ({total})")
                    confidence = min(confidence, 65)

        critical_flags = [f for f in flags if any(k in f for k in ["mismatch", "Total amount", "could not be reliably identified"])]
        if critical_flags:
            confidence = min(confidence, 60)

        extracted["validation_flags"] = list(dict.fromkeys(flags))
        extracted["confidence"] = max(10, min(confidence, 98))
        return extracted

    def _grounded_heuristic_invoice_extraction(self, raw_text: str, filename: str) -> dict:
        """Grounded rule-based extraction fallback that never invents fake amounts."""
        vendor = "Unknown Vendor"
        customer = "Not found"
        inv_num = ""
        inv_date = ""
        due_date = ""
        subtotal = None
        tax = None
        total = None
        currency = "USD"
        payment_info = "Not found"
        line_items = []

        inv_match = re.search(r"(?:invoice\s*(?:#|no|number)?[:\s]+)([A-Z0-9\-_/]+)", raw_text, re.IGNORECASE)
        if inv_match and len(inv_match.group(1)) > 2:
            inv_num = inv_match.group(1).strip()

        date_matches = re.findall(r"\b(?:\d{1,2}[/-]\d{1,2}[/-]\d{2,4}|(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s+\d{1,2},?\s+\d{4})\b", raw_text, re.IGNORECASE)
        if date_matches:
            inv_date = date_matches[0]
            if len(date_matches) > 1:
                due_date = date_matches[1]

        if "₹" in raw_text or "INR" in raw_text:
            currency = "INR"
        elif "€" in raw_text or "EUR" in raw_text:
            currency = "EUR"
        elif "£" in raw_text or "GBP" in raw_text:
            currency = "GBP"

        for line in raw_text.splitlines():
            line_str = line.strip()
            if re.search(r"sub\s*total|amount\s+before\s+tax", line_str, re.IGNORECASE) and subtotal is None:
                subtotal = self._normalize_money(line_str)
            elif re.search(r"sales\s+tax|total\s+gst|tax", line_str, re.IGNORECASE) and tax is None:
                tax = self._normalize_money(line_str)
            elif re.search(r"total\s+due|total\s+amount|grand\s+total", line_str, re.IGNORECASE) and total is None:
                total = self._normalize_money(line_str)
            elif re.search(r"payment\s+(?:via|method|mode)", line_str, re.IGNORECASE) and payment_info == "Not found":
                payment_info = line_str

        return {
            "vendor": vendor,
            "customer_name": customer,
            "invoice_number": inv_num,
            "invoice_date": inv_date,
            "due_date": due_date,
            "currency": currency,
            "subtotal": subtotal,
            "tax": tax,
            "cgst": None,
            "sgst": None,
            "igst": None,
            "tcs": None,
            "total": total,
            "payment_info": payment_info,
            "line_items": line_items,
            "validation_flags": ["Extracted using rule-based engine"],
            "confidence": 65,
            "reasoning": "Rule-based fallback used."
        }

    def extract_multiple_invoices(self, files_list: list) -> dict:
        """
        Batch processes multiple uploaded invoices with isolated contexts and duplicate auditing.
        Takes list of tuples/dicts: [(file_path, original_filename), ...]
        """
        results = []
        seen_numbers = {}

        for item in files_list:
            if isinstance(item, tuple):
                f_path, f_name = item
            else:
                f_path = item.get("path")
                f_name = item.get("name")

            raw_text = self.extract_document_text(f_path)
            extracted = self.extract_invoice_data(raw_text, f_name)
            extracted["file_name"] = f_name
            extracted["file_path"] = f_path

            # Batch Duplicate Check
            inv_num = extracted.get("invoice_number", "").strip()
            if inv_num:
                if inv_num in seen_numbers:
                    extracted["validation_flags"].append(f"Duplicate Alert: Invoice #{inv_num} appears multiple times in this upload batch (also in {seen_numbers[inv_num]})")
                    extracted["confidence"] = min(extracted["confidence"], 45)
                else:
                    seen_numbers[inv_num] = f_name

            results.append(extracted)

        valid_count = sum(1 for r in results if r["confidence"] >= 80 and not any("Alert" in f or "mismatch" in f for f in r["validation_flags"]))
        review_count = len(results) - valid_count

        return {
            "invoices": results,
            "summary": {
                "total": len(results),
                "valid": valid_count,
                "needs_review": review_count
            }
        }

    # =========================================================================
    # 2. RESUME AI: SCREENING, SKILLS MATCHING & COMPARATIVE RANKING
    # =========================================================================

    def screen_resume(self, raw_text: str, jd_text: str, target_skills: list) -> dict:
        """
        Screens candidate resume against target Job Description using Google Gemini.
        Extracts candidate name, contact, skills, education, and experience.
        Computes match score, skills match %, missing skills, and hiring recommendation.
        Never invents qualifications.
        """
        if not raw_text or not raw_text.strip():
            return {
                "candidate_name": "Unknown Candidate",
                "email": "Not found",
                "phone": "Not found",
                "skills": [],
                "experience": "No experience text found",
                "education": "Not found",
                "certifications": [],
                "projects": "Not found",
                "match_score": 0,
                "skills_match_pct": 0,
                "experience_match_pct": 0,
                "matching_skills": [],
                "missing_skills": target_skills or [],
                "recommendation": "Low Match",
                "ai_summary": "Empty resume file.",
                "confidence": 0
            }

        prompt = f"""You are an expert technical recruiter and talent evaluation AI.
Screen the candidate resume against the target Job Description below.

CRITICAL RULES:
1. Extract information strictly from the resume. NEVER invent skills, degrees, or experience.
2. If contact info, experience, or education is missing, set to "Not found".
3. Evaluate matching skills against the target skills list accurately.
4. Calculate realistic match scores (0-100%).
5. Recommendation must be: "Strong Match" (80-100%), "Review" (60-79%), or "Low Match" (<60%).

TARGET JOB DESCRIPTION:
{jd_text}

TARGET KEY SKILLS:
{json.dumps(target_skills)}

CANDIDATE RESUME TEXT:
{raw_text[:15000]}

OUTPUT STRICT JSON FORMAT:
{{
    "candidate_name": "string",
    "email": "string",
    "phone": "string",
    "skills": ["string"],
    "experience": "string",
    "education": "string",
    "certifications": ["string"],
    "projects": "string",
    "match_score": integer (0 to 100),
    "skills_match_pct": integer (0 to 100),
    "experience_match_pct": integer (0 to 100),
    "matching_skills": ["string"],
    "missing_skills": ["string"],
    "recommendation": "Strong Match" | "Review" | "Low Match",
    "ai_summary": "string (2-3 sentences explaining strengths and skill alignment)",
    "confidence": integer (0 to 100)
}}"""

        response_text = self.call_gemini(
            prompt,
            system_instruction="You are an objective talent assessment AI. Extract and evaluate candidates strictly based on provided resumes.",
            json_format=True
        )

        extracted = self._clean_json_response(response_text)
        if not extracted or not isinstance(extracted, dict):
            extracted = self._grounded_heuristic_resume_screening(raw_text, jd_text, target_skills)

        return extracted

    def screen_multiple_resumes(self, resumes_data: list, jd_text: str, target_skills: list) -> dict:
        """
        Screens and ranks multiple resumes against a target Job Description.
        Takes list of dicts: [{'name': filename, 'text': text}, ...]
        Returns individual evaluations and comparative ranking analysis.
        """
        evaluations = []
        for r in resumes_data:
            eval_result = self.screen_resume(r.get("text", ""), jd_text, target_skills)
            eval_result["file_name"] = r.get("name", "Resume")
            evaluations.append(eval_result)

        evaluations.sort(key=lambda x: x.get("match_score", 0), reverse=True)

        summary_payload = [
            {
                "rank": idx + 1,
                "name": e.get("candidate_name"),
                "score": e.get("match_score"),
                "recommendation": e.get("recommendation"),
                "matching_skills": e.get("matching_skills", []),
                "missing_skills": e.get("missing_skills", [])
            }
            for idx, e in enumerate(evaluations)
        ]

        comp_prompt = f"""Compare the following screened candidates for the job:
Job: {jd_text}
Candidate Scores:
{json.dumps(summary_payload, indent=2)}

Provide a concise 2-4 sentence comparative synthesis explaining who is strongest and why."""

        comparative_text = self.call_gemini(
            comp_prompt,
            system_instruction="You are an expert HR talent director. Compare candidates objectively.",
            json_format=False
        )

        return {
            "candidates": evaluations,
            "comparative_summary": comparative_text or "Candidates ranked by match score against job description."
        }

    def _grounded_heuristic_resume_screening(self, raw_text: str, jd_text: str, target_skills: list) -> dict:
        """Rule-based resume screening fallback."""
        name = "Candidate"
        lines = [line.strip() for line in raw_text.splitlines() if line.strip()]
        if lines:
            name = lines[0][:60]

        email_match = re.search(r"[\w\.-]+@[\w\.-]+\.\w+", raw_text)
        email = email_match.group(0) if email_match else "Not found"

        phone_match = re.search(r"(?:\+?\d{1,3}[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}", raw_text)
        phone = phone_match.group(0) if phone_match else "Not found"

        matching = []
        missing = []
        for skill in (target_skills or []):
            if re.search(rf"\b{re.escape(skill)}\b", raw_text, re.IGNORECASE):
                matching.append(skill)
            else:
                missing.append(skill)

        total_skills = len(target_skills) if target_skills else 1
        skill_pct = int((len(matching) / total_skills) * 100)
        match_score = skill_pct

        rec = "Strong Match" if match_score >= 80 else ("Review" if match_score >= 60 else "Low Match")

        return {
            "candidate_name": name,
            "email": email,
            "phone": phone,
            "skills": matching,
            "experience": "Extracted via rule-based parser",
            "education": "Not found",
            "certifications": [],
            "projects": "Not found",
            "match_score": match_score,
            "skills_match_pct": skill_pct,
            "experience_match_pct": 60,
            "matching_skills": matching,
            "missing_skills": missing,
            "recommendation": rec,
            "ai_summary": f"Candidate demonstrates skills in {', '.join(matching[:4]) if matching else 'general areas'}.",
            "confidence": 75
        }

    # =========================================================================
    # 3. DOCUMENT SUMMARIZATION
    # =========================================================================

    def summarize_document(self, raw_text: str, filename: str = "", detail_level: str = "standard") -> dict:
        """
        Produces a comprehensive structured document summary using Google Gemini.
        Returns short summary, detailed summary, key points, numbers, dates, entities, action items, and risks.
        """
        if not raw_text or not raw_text.strip():
            return {
                "title": filename or "Empty Document",
                "short_summary": "The document contained no readable text.",
                "detailed_summary": "",
                "key_points": [],
                "important_numbers": [],
                "important_dates": [],
                "entities": [],
                "action_items": [],
                "risks_and_issues": []
            }

        prompt = f"""Analyze and summarize the following document.
DOCUMENT NAME: {filename}
CONTENT:
{raw_text[:18000]}

OUTPUT STRICT JSON:
{{
    "title": "Concise descriptive title of the document",
    "short_summary": "1-2 sentence executive summary",
    "detailed_summary": "Thorough paragraph explaining the document purpose and contents",
    "key_points": ["Key takeaway point 1", "Key takeaway point 2"],
    "important_numbers": ["Number with its label/context (e.g. Total Due: ₹6,033.00)"],
    "important_dates": ["Date with its significance (e.g. Due Date: December 28, 2026)"],
    "entities": ["Organizations, vendors, clients, people, or departments mentioned"],
    "action_items": ["Pending action or required next step"],
    "risks_and_issues": ["Compliance warnings, discrepancies, or notes"]
}}"""

        response_text = self.call_gemini(
            prompt,
            system_instruction="You are an enterprise document analyst. Summarize strictly based on the text without inventing details.",
            json_format=True
        )

        res = self._clean_json_response(response_text)
        if not res or not isinstance(res, dict):
            res = {
                "title": filename or "Document Summary",
                "short_summary": raw_text[:200] + "...",
                "detailed_summary": raw_text[:600],
                "key_points": [line[:100] for line in raw_text.splitlines() if len(line) > 20][:5],
                "important_numbers": [],
                "important_dates": [],
                "entities": [],
                "action_items": [],
                "risks_and_issues": []
            }
        return res

    def summarize_documents(self, documents: list) -> dict:
        """
        Synthesizes information across multiple documents.
        Takes list of dicts: [{'name': filename, 'text': text}, ...]
        """
        doc_contexts = []
        for idx, d in enumerate(documents):
            doc_contexts.append(f"--- DOCUMENT {idx+1}: {d.get('name', 'Doc')} ---\n{d.get('text', '')[:5000]}")

        combined = "\n\n".join(doc_contexts)
        prompt = f"""Summarize and compare the following {len(documents)} business documents:

{combined}

OUTPUT STRICT JSON:
{{
    "overview": "High-level summary of the entire collection",
    "document_summaries": [
        {{"document_name": "string", "summary": "string", "key_metric": "string"}}
    ],
    "cross_document_insights": ["Insight 1 comparing documents", "Insight 2"],
    "total_financial_impact": "string or null"
}}"""

        response_text = self.call_gemini(prompt, json_format=True)
        return self._clean_json_response(response_text) or {"overview": "Multi-document analysis completed."}

    # =========================================================================
    # 4. DOCUMENT-AWARE AI COPILOT & MULTI-DOCUMENT CONTEXT
    # =========================================================================

    def ask_about_document(self, raw_text: str, question: str, filename: str = "Document") -> str:
        """Answers a user question based strictly on a single document's text."""
        return self.ask_about_documents([{"name": filename, "text": raw_text}], question)

    def ask_about_documents(self, documents: list, question: str) -> str:
        """
        Answers a user question across one or multiple documents.
        Explicitly cites source document names.
        If information is absent, states: 'I couldn't find that information in the uploaded documents.'
        """
        if not documents:
            return "No documents are currently attached to this conversation context."

        doc_sections = []
        for d in documents:
            doc_sections.append(f"=== SOURCE: {d.get('name', 'Document')} ===\n{d.get('text', '')[:10000]}")

        context_block = "\n\n".join(doc_sections)

        prompt = f"""You are the SmartBiz Enterprise AI Copilot.
Answer the user question using ONLY the content in the uploaded documents below.

STRICT ACCURACY RULES:
1. Base your answer strictly on the provided documents.
2. Always attribute information to its specific document name (e.g., "According to invoice_garments.pdf, ...").
3. For financial questions, cite the exact figures and labels from the document.
4. If the question asks for comparisons (e.g. 'which invoice has highest total', 'compare candidates'), compare only the attached documents.
5. If the requested information is NOT in the documents, respond truthfully:
   "I couldn't find that information in the uploaded documents."
6. NEVER fabricate or invent facts, numbers, or dates.

UPLOADED DOCUMENTS:
{context_block}

USER QUESTION:
{question}
"""
        reply = self.call_gemini(
            prompt,
            system_instruction="You are SmartBiz Copilot. Be professional, accurate, and cite document names for all statements.",
            json_format=False
        )

        if not reply:
            return "I couldn't process the uploaded documents at this moment. Please verify the documents and try again."

        return reply

    def copilot_chat(
        self,
        message: str,
        context_docs: list = None,
        user_info: dict = None,
        chat_history: list = None
    ) -> dict:
        """
        Central Copilot chat endpoint for the SmartBiz interface.
        Supports general assistant requests and document-grounded inquiries.
        """
        user_name = (user_info or {}).get("name", "User")
        user_role = (user_info or {}).get("role", "Employee")
        user_dept = (user_info or {}).get("department", "SmartBiz")

        if context_docs and len(context_docs) > 0:
            answer = self.ask_about_documents(context_docs, message)
            doc_names = [d.get("name", "Doc") for d in context_docs]
            return {
                "reply": answer,
                "engine": f"Google Gemini ({self.primary_model})",
                "model": self.primary_model,
                "sources": doc_names,
                "has_context": True
            }

        # If user asks about a document but no document context is attached
        doc_keywords = ['this document', 'the document', 'uploaded document', 'this invoice', 'the invoice', 'uploaded invoice', 'this resume', 'the resume', 'uploaded resume', 'the file', 'this file', 'uploaded file', 'the pdf', 'this pdf', 'my document', 'my invoice', 'my file']
        msg_low = message.lower()
        if any(k in msg_low for k in doc_keywords):
            return {
                "reply": "The document content is not currently available to the assistant. Please select a document from the **Context** dropdown at the top of the Copilot drawer, or attach a file directly using the 📎 paperclip button.",
                "engine": f"Google Gemini ({self.primary_model})",
                "model": self.primary_model,
                "sources": [],
                "has_context": False
            }

        system_instruction = (
            f"You are the SmartBiz Central AI Copilot powered by Google Gemini ({self.primary_model}). "
            f"You assist {user_name} ({user_role}, {user_dept}) with business automation, workflows, "
            f"invoices, HR recruitment, CRM lead qualification, customer support, and HITL governance. "
            f"Be professional, concise, actionable, and helpful."
        )

        history_context = ""
        if chat_history and len(chat_history) > 0:
            recent = chat_history[-6:]
            history_context = "\n".join([f"{h.get('sender')}: {h.get('text')}" for h in recent]) + "\n"

        prompt = f"{history_context}User: {message}\nAssistant:"
        reply = self.call_gemini(prompt, system_instruction=system_instruction, json_format=False)

        if not reply:
            reply = "Hello! I am your SmartBiz AI Copilot powered by Google Gemini. How may I assist you with your business workflows today?"

        return {
            "reply": reply,
            "engine": f"Google Gemini ({self.primary_model})",
            "model": self.primary_model,
            "sources": [],
            "has_context": False
        }

    # =========================================================================
    # 5. SPECIALIZED ENTERPRISE AUTOMATIONS: LEADS & SUPPORT TICKETS
    # =========================================================================

    def score_lead(self, lead_data: dict) -> dict:
        """Scores an inbound lead using Google Gemini."""
        prompt = f"""Score and qualify this sales lead:
{json.dumps(lead_data, indent=2)}

OUTPUT STRICT JSON:
{{
    "score": integer (0 to 100),
    "category": "HOT" | "WARM" | "COLD",
    "reasons": ["Key score driver 1", "Key score driver 2"],
    "recommended_action": "Immediate executive call" | "Schedule demo" | "Nurture sequence",
    "recommended_department": "Sales & Business Development",
    "confidence": integer (0 to 100)
}}"""

        res_text = self.call_gemini(prompt, json_format=True)
        res = self._clean_json_response(res_text)
        if not res or not isinstance(res, dict):
            budget = float(lead_data.get("budget", 0) or 0)
            score = 85 if budget >= 50000 else (65 if budget >= 20000 else 40)
            cat = "HOT" if score >= 80 else ("WARM" if score >= 60 else "COLD")
            res = {
                "score": score,
                "category": cat,
                "reasons": [f"Budget: ${budget:,.2f}", f"Company Size: {lead_data.get('company_size')}"],
                "recommended_action": "Priority sales follow-up" if cat == "HOT" else "Standard follow-up",
                "recommended_department": "Sales & Business Development",
                "confidence": 88
            }
        return res

    def classify_ticket(self, subject: str, description: str) -> dict:
        """NLP support ticket classification using Google Gemini."""
        prompt = f"""Classify this customer support ticket:
Subject: {subject}
Description: {description}

OUTPUT STRICT JSON:
{{
    "category": "Billing" | "Technical" | "Account" | "Compliance" | "Feature Request" | "General",
    "priority": "Critical" | "High" | "Medium" | "Low",
    "sentiment": "Positive" | "Neutral" | "Negative",
    "department": "Finance" | "Support" | "Sales" | "HR" | "Compliance",
    "confidence": integer (0 to 100),
    "reasoning": "Brief explanation"
}}"""

        res_text = self.call_gemini(prompt, json_format=True)
        res = self._clean_json_response(res_text)
        if not res or not isinstance(res, dict):
            is_billing = any(k in f"{subject} {description}".lower() for k in ["charged", "invoice", "refund", "bill", "payment"])
            res = {
                "category": "Billing" if is_billing else "General",
                "priority": "High" if is_billing else "Medium",
                "sentiment": "Negative" if any(w in f"{subject} {description}".lower() for w in ["twice", "error", "wrong", "fail", "broken"]) else "Neutral",
                "department": "Finance" if is_billing else "Support",
                "confidence": 85,
                "reasoning": "Keyword-based classification fallback."
            }
        return res

    def generate_support_response(
        self,
        customer_name: str,
        subject: str,
        description: str,
        category: str,
        sentiment: str
    ) -> str:
        """Drafts an empathetic, professional support response using Google Gemini."""
        prompt = f"""Draft a professional, empathetic customer support reply:
Customer: {customer_name}
Subject: {subject}
Ticket Description: {description}
Category: {category}
Sentiment: {sentiment}

Provide a courteous, helpful response addressing their issue directly."""

        reply = self.call_gemini(prompt, json_format=False)
        if not reply:
            reply = f"Dear {customer_name},\n\nThank you for reaching out to SmartBiz Support regarding '{subject}'. We have received your request and our team is actively reviewing the details. We will provide an update shortly.\n\nBest regards,\nSmartBiz Customer Support"
        return reply

    # =========================================================================
    # 6. SYSTEM STATUS & DIAGNOSTICS
    # =========================================================================

    def get_ai_status(self) -> dict:
        """Returns real-time status of Gemini as Central Engine."""
        is_gemini_active = bool(self.api_key)
        active_desc = f"Google Gemini ({self.primary_model}) [Central Engine]" if is_gemini_active else "Rule Engine Fallback"

        return {
            "active_engine": active_desc,
            "tasks_engine": f"Google Gemini ({self.primary_model})" if is_gemini_active else "Rule Engine Fallback",
            "assistant_engine": f"Google Gemini Copilot ({self.primary_model})" if is_gemini_active else "Offline Assistant",
            "gemini": {
                "available": is_gemini_active,
                "model": self.primary_model,
                "key_configured": bool(self.api_key),
                "models_supported": self.models_to_try
            },
            "ollama": {
                "available": False,
                "model": "Replaced by Google Gemini",
                "url": self.ollama_base_url
            }
        }

    # =========================================================================
    # BACKWARD COMPATIBILITY STUBS
    # =========================================================================

    def check_ollama_status(self) -> dict:
        """Backward compatibility stub."""
        return {"available": False, "model": "Replaced by Google Gemini", "url": self.ollama_base_url}

    def call_ollama(self, prompt: str, system_instruction: str = None, timeout: int = 120, max_tokens: int = 250) -> str:
        """Deprecated: routes to Google Gemini."""
        return self.call_gemini(prompt, system_instruction=system_instruction, json_format=False)

    def call_assistant(self, prompt: str, system_instruction: str = None, timeout: int = 120, max_tokens: int = 150) -> str:
        """Routes assistant calls to Google Gemini."""
        return self.call_gemini(prompt, system_instruction=system_instruction, json_format=False)

    def call_llm(self, prompt: str, system_instruction: str = None) -> str:
        """Generic LLM call routed to Google Gemini."""
        return self.call_gemini(prompt, system_instruction=system_instruction, json_format=False)


# Global Singleton Instance
ai_service = AIService()
