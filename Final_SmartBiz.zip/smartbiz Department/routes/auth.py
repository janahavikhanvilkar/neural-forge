from flask import Blueprint, render_template, request, redirect, url_for, flash, session, jsonify
from models.models import db, User
from utils.helpers import log_activity

auth_bp = Blueprint('auth', __name__)

def normalize_department(dept_str):
    """Normalize department dropdown input to standard uppercase code."""
    if not dept_str:
        return None
    dept_clean = dept_str.strip().upper()
    mapping = {
        'ADMIN': 'ADMIN',
        'ADMINISTRATOR': 'ADMIN',
        'ADMINISTRATION': 'ADMIN',
        'GLOBAL ADMINISTRATION': 'ADMIN',
        'FINANCE': 'FINANCE',
        'FINANCE & ACCOUNTING': 'FINANCE',
        'HR': 'HR',
        'HUMAN RESOURCES': 'HR',
        'HUMAN RESOURCES (HR)': 'HR',
        'SALES': 'SALES',
        'SALES & BUSINESS DEVELOPMENT': 'SALES',
        'SUPPORT': 'SUPPORT',
        'CUSTOMER SUPPORT': 'SUPPORT',
        'CUSTOMER SUPPORT & SERVICE': 'SUPPORT',
        'COMPLIANCE': 'COMPLIANCE',
        'OPERATIONS & COMPLIANCE': 'COMPLIANCE',
        '1': 'FINANCE',
        '2': 'HR',
        '3': 'SALES',
        '4': 'SUPPORT',
        '5': 'COMPLIANCE',
    }
    return mapping.get(dept_clean)

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        selected_dept = request.form.get('department', '').strip()
        email = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')
        
        # 1. Department is selected
        if not selected_dept:
            flash("Please select your department.", "danger")
            return render_template('login.html', selected_dept=selected_dept, email=email)

        # 2 & 3. Email and password entered
        if not email or not password:
            flash("Invalid email or password.", "danger")
            return render_template('login.html', selected_dept=selected_dept, email=email)

        # 4. Email exists in database
        user = User.query.filter(User.email.ilike(email)).first()
        if not user:
            flash("Invalid email or password.", "danger")
            return render_template('login.html', selected_dept=selected_dept, email=email)

        # 5. Password is correct
        if not user.check_password(password):
            flash("Invalid email or password.", "danger")
            return render_template('login.html', selected_dept=selected_dept, email=email)

        # 6. User account is active
        if not user.is_active:
            flash("This account is currently deactivated. Please contact your system administrator.", "danger")
            return render_template('login.html', selected_dept=selected_dept, email=email)

        # 7. Selected department matches the user's actual department/role
        norm_dept = normalize_department(selected_dept)
        user_role = (user.role or '').upper()

        dept_matches = False
        if norm_dept == 'ADMIN':
            # Admin special case: validate user has ADMIN role; department_id is NULL
            if user_role == 'ADMIN':
                dept_matches = True
        else:
            # Non-admin: verify selected department against user's actual department code or role
            user_dept_code = (user.department_code or '').upper()
            if norm_dept and (norm_dept == user_role or norm_dept == user_dept_code):
                dept_matches = True

        if not dept_matches:
            flash("The selected department does not match this account.", "danger")
            return render_template('login.html', selected_dept=selected_dept, email=email)

        # ALL checks passed: create session preserving all required keys
        session['user_id'] = user.id
        session['user_name'] = user.name
        session['email'] = user.email
        session['user_email'] = user.email
        session['role'] = (user.role or '').upper()
        session['department_id'] = user.department_id
        session['department_name'] = user.department_name
        session['department_code'] = user.department_code
        session['sub_department_id'] = user.sub_department_id
        session['sub_department_name'] = user.sub_department_name
        
        log_activity("User Login", "Auth", f"User {user.name} ({user.email}) logged in successfully as {user.role.upper()} ({user.department_name})", department_name=user.department_name)
        flash(f"Welcome back, {user.name}! ({user.department_name})", "success")
        
        next_url = request.args.get('next')
        return redirect(next_url or url_for('dashboard.index'))
        
    return render_template('login.html')

@auth_bp.route('/quick-login/<role>')
def quick_login(role):
    """Allows one-click demo login for all 6 roles (Admin + 5 Departments)."""
    role = role.lower()
    role_email_map = {
        'admin': 'admin@smartbiz.local',
        'finance': 'finance@smartbiz.local',
        'sales': 'sales@smartbiz.local',
        'hr': 'hr@smartbiz.local',
        'support': 'support@smartbiz.local',
        'compliance': 'compliance@smartbiz.local'
    }
    
    email = role_email_map.get(role, 'admin@smartbiz.local')
    user = User.query.filter(User.email.ilike(email)).first()
    
    if not user:
        # Fallback to .ai email or role query
        fallback_email = email.replace('.local', '.ai')
        user = User.query.filter(User.email.ilike(fallback_email)).first()
        if not user:
            user = User.query.filter(User.role.ilike(role)).first()
        
    if user:
        if not user.is_active:
            flash("This account is deactivated.", "danger")
            return redirect(url_for('auth.login'))

        session['user_id'] = user.id
        session['user_name'] = user.name
        session['email'] = user.email
        session['user_email'] = user.email
        session['role'] = (user.role or '').upper()
        session['department_id'] = user.department_id
        session['department_name'] = user.department_name
        session['department_code'] = user.department_code
        session['sub_department_id'] = user.sub_department_id
        session['sub_department_name'] = user.sub_department_name
        
        log_activity("Quick Login", "Auth", f"Quick login as {user.name} ({user.role.upper()} – {user.department_name})", department_name=user.department_name)
        flash(f"Logged in as {user.name} ({user.department_name})", "info")
        return redirect(url_for('dashboard.index'))
    
    flash("Demo user not found. Please re-seed the database.", "warning")
    return redirect(url_for('auth.login'))

@auth_bp.route('/logout')
def logout():
    user_name = session.get('user_name', 'User')
    dept_name = session.get('department_name', 'Global')
    log_activity("User Logout", "Auth", f"User {user_name} logged out", department_name=dept_name)
    session.clear()
    flash("You have been securely logged out.", "info")
    return redirect(url_for('auth.login'))

