from flask import Blueprint, request, jsonify, session
from models.models import db, Invoice, Lead, Resume, SupportTicket, Notification, ActivityLog, ExpenseClaim, ContractProposal, EmployeeDocument
from utils.helpers import login_required, get_current_user
from services.ai_service import ai_service

api_bp = Blueprint('api', __name__)

@api_bp.route('/api/search')
@login_required
def global_search():
    q = request.args.get('q', '').strip()
    if not q or len(q) < 2:
        return jsonify({'results': []})

    user = get_current_user()
    role = (user.role or '').upper() if user else 'GUEST'
    dept_code = (user.department_code or '').upper() if user else 'GUEST'

    results = []

    # Invoices (Finance or Admin)
    if role == 'ADMIN' or dept_code == 'FINANCE':
        invoices = Invoice.query.filter(
            (Invoice.invoice_number.ilike(f'%{q}%')) |
            (Invoice.vendor.ilike(f'%{q}%')) |
            (Invoice.customer_name.ilike(f'%{q}%'))
        ).limit(3).all()
        for inv in invoices:
            results.append({
                'type': 'Invoice',
                'title': f"Invoice #{inv.invoice_number or inv.id} - {inv.vendor}",
                'subtitle': f"${inv.total:,.2f} ({inv.status})",
                'link': f"/invoices/{inv.id}",
                'badge': inv.status
            })

    # Leads (Sales or Admin)
    if role == 'ADMIN' or dept_code == 'SALES':
        leads = Lead.query.filter(
            (Lead.name.ilike(f'%{q}%')) |
            (Lead.company.ilike(f'%{q}%')) |
            (Lead.email.ilike(f'%{q}%'))
        ).limit(3).all()
        for lead in leads:
            results.append({
                'type': 'Lead',
                'title': f"{lead.name} @ {lead.company}",
                'subtitle': f"Score: {lead.score}/100 ({lead.category})",
                'link': f"/leads",
                'badge': lead.category
            })

    # Resumes (HR or Admin)
    if role == 'ADMIN' or dept_code == 'HR':
        resumes = Resume.query.filter(
            (Resume.candidate_name.ilike(f'%{q}%')) |
            (Resume.skills.ilike(f'%{q}%'))
        ).limit(3).all()
        for res in resumes:
            results.append({
                'type': 'Resume',
                'title': f"{res.candidate_name}",
                'subtitle': f"Match: {res.match_score}% ({res.recommendation})",
                'link': f"/resumes",
                'badge': res.recommendation
            })

    # Support Tickets (Support or Admin)
    if role == 'ADMIN' or dept_code == 'SUPPORT':
        tickets = SupportTicket.query.filter(
            (SupportTicket.ticket_number.ilike(f'%{q}%')) |
            (SupportTicket.subject.ilike(f'%{q}%')) |
            (SupportTicket.customer_name.ilike(f'%{q}%'))
        ).limit(3).all()
        for t in tickets:
            results.append({
                'type': 'Ticket',
                'title': f"{t.ticket_number}: {t.subject}",
                'subtitle': f"[{t.priority}] {t.category} - {t.department}",
                'link': f"/support",
                'badge': t.priority
            })

    return jsonify({'results': results})

@api_bp.route('/api/notifications')
@login_required
def get_notifications():
    user = get_current_user()
    role = (user.role or '').upper() if user else 'ADMIN'
    dept_id = user.department_id if user else None

    if role == 'ADMIN':
        notifs = Notification.query.order_by(Notification.created_at.desc()).limit(15).all()
    else:
        notifs = Notification.query.filter(
            (Notification.role_target.in_(['ALL', role])) |
            (Notification.department_id == dept_id) |
            (Notification.user_id == session.get('user_id'))
        ).order_by(Notification.created_at.desc()).limit(10).all()

    unread_count = sum(1 for n in notifs if not n.is_read)
    return jsonify({
        'unread_count': unread_count,
        'notifications': [n.to_dict() for n in notifs]
    })

@api_bp.route('/api/notifications/mark-read', methods=['POST'])
@login_required
def mark_notifications_read():
    user = get_current_user()
    role = (user.role or '').upper() if user else 'ADMIN'
    dept_id = user.department_id if user else None

    if role == 'ADMIN':
        notifs = Notification.query.filter_by(is_read=False).all()
    else:
        notifs = Notification.query.filter(
            Notification.is_read == False,
            (Notification.role_target.in_(['ALL', role])) |
            (Notification.department_id == dept_id) |
            (Notification.user_id == session.get('user_id'))
        ).all()

    for n in notifs:
        n.is_read = True
    db.session.commit()
    return jsonify({'success': True})


@api_bp.route('/api/ai/status')
def get_ai_status():
    """Returns real-time status of central Google Gemini AI engine."""
    return jsonify(ai_service.get_ai_status())


@api_bp.route('/api/copilot/documents')
@login_required
def get_copilot_documents():
    """Returns all available documents in the system for Copilot context selection."""
    invoices = Invoice.query.order_by(Invoice.created_at.desc()).limit(15).all()
    resumes = Resume.query.order_by(Resume.created_at.desc()).limit(15).all()

    docs = []
    for inv in invoices:
        docs.append({
            'id': f"invoice_{inv.id}",
            'real_id': inv.id,
            'type': 'invoice',
            'name': inv.file_name or f"Invoice_{inv.invoice_number or inv.id}.pdf",
            'label': f"Invoice #{inv.invoice_number or inv.id} ({inv.vendor} - {inv.currency} {inv.total:,.2f})",
            'date': inv.invoice_date or (inv.created_at.strftime('%Y-%m-%d') if inv.created_at else '')
        })

    for res in resumes:
        docs.append({
            'id': f"resume_{res.id}",
            'real_id': res.id,
            'type': 'resume',
            'name': res.file_name or f"Resume_{res.candidate_name}.pdf",
            'label': f"Resume: {res.candidate_name} ({res.match_score}% Match)",
            'date': res.created_at.strftime('%Y-%m-%d') if res.created_at else ''
        })

    return jsonify({'documents': docs})


@api_bp.route('/api/copilot/upload', methods=['POST'])
@login_required
def copilot_upload_document():
    """Direct document upload from the Copilot drawer for immediate document-grounded Q&A."""
    if 'file' not in request.files:
        return jsonify({'error': 'No file uploaded'}), 400

    file = request.files['file']
    if not file or file.filename == '':
        return jsonify({'error': 'No file selected'}), 400

    from werkzeug.utils import secure_filename
    import uuid
    import os
    from config import Config

    original_name = secure_filename(file.filename)
    unique_name = f"copilot_{uuid.uuid4().hex[:8]}_{original_name}"
    save_path = os.path.join(Config.UPLOAD_FOLDER, unique_name)
    file.save(save_path)

    raw_text = ai_service.extract_document_text(save_path)
    summary = ai_service.summarize_document(raw_text, original_name)

    return jsonify({
        'success': True,
        'name': original_name,
        'path': save_path,
        'text': raw_text[:8000],
        'summary': summary
    })


@api_bp.route('/api/document/summarize', methods=['POST'])
@login_required
def summarize_doc():
    """Generates structured Gemini summary for a document."""
    data = request.get_json() or {}
    doc_type = data.get('type')
    doc_id = data.get('id')
    raw_text = data.get('text', '')
    doc_name = data.get('name', 'Document')

    if doc_type == 'invoice' and doc_id:
        inv = Invoice.query.get(doc_id)
        if inv and inv.raw_text:
            raw_text = inv.raw_text
            doc_name = inv.file_name or f"Invoice_{inv.invoice_number or inv.id}"
    elif doc_type == 'resume' and doc_id:
        res = Resume.query.get(doc_id)
        if res and res.raw_text:
            raw_text = res.raw_text
            doc_name = res.file_name or f"Resume_{res.candidate_name}"

    summary = ai_service.summarize_document(raw_text, doc_name)
    return jsonify(summary)


@api_bp.route('/api/assistant/chat', methods=['POST'])
def assistant_chat():
    """Centralized SmartBiz AI Copilot endpoint powered by Google Gemini with Document Context."""
    data = request.get_json() or {}
    message = (data.get('message') or '').strip()
    page_context = data.get('context', {})
    doc_selection = data.get('document_context', 'auto')
    direct_doc_text = data.get('doc_text')
    direct_doc_name = data.get('doc_name')
    history = data.get('history', [])

    if not message:
        return jsonify({'error': 'Message cannot be empty'}), 400

    user = get_current_user()
    user_info = {
        'name': user.name if user else 'Employee',
        'role': user.role if user else 'User',
        'department': user.department_name if user else 'General'
    }

    context_docs = []

    # 1. Direct document attached via chat upload
    if direct_doc_text:
        context_docs.append({
            'name': direct_doc_name or 'Uploaded Document',
            'text': direct_doc_text
        })

    # 2. Explicit document selection in UI
    elif doc_selection and doc_selection not in ['auto', 'none', 'all_invoices', 'all_resumes']:
        if doc_selection.startswith('invoice_'):
            inv_id = int(doc_selection.replace('invoice_', ''))
            inv = Invoice.query.get(inv_id)
            if inv:
                context_docs.append({
                    'name': inv.file_name or f"Invoice #{inv.invoice_number or inv.id}",
                    'text': inv.raw_text or f"Vendor: {inv.vendor}, Total: {inv.total}, Invoice #: {inv.invoice_number}"
                })
        elif doc_selection.startswith('resume_'):
            res_id = int(doc_selection.replace('resume_', ''))
            res = Resume.query.get(res_id)
            if res:
                context_docs.append({
                    'name': res.file_name or f"Resume_{res.candidate_name}",
                    'text': res.raw_text or f"Candidate: {res.candidate_name}, Skills: {res.skills}, Score: {res.match_score}"
                })

    # 3. Contextual auto-detection based on current URL
    elif doc_selection == 'auto':
        path = page_context.get('path', '')
        if '/invoices/' in path:
            try:
                inv_id = int(path.split('/invoices/')[-1].split('/')[0])
                inv = Invoice.query.get(inv_id)
                if inv and inv.raw_text:
                    context_docs.append({
                        'name': inv.file_name or f"Invoice #{inv.invoice_number or inv.id}",
                        'text': inv.raw_text
                    })
            except Exception:
                pass

    # 4. Multi-document queries (e.g. "all invoices", "highest total", "compare invoices")
    msg_lower = message.lower()
    if not context_docs and (doc_selection == 'all_invoices' or any(k in msg_lower for k in ['all invoice', 'highest total', 'which invoice', 'compare invoice', 'compare these two invoice', 'find invoice'])):
        invoices = Invoice.query.order_by(Invoice.created_at.desc()).limit(8).all()
        for inv in invoices:
            if inv.raw_text:
                context_docs.append({
                    'name': inv.file_name or f"Invoice #{inv.invoice_number or inv.id}",
                    'text': inv.raw_text[:2500]
                })

    if not context_docs and (doc_selection == 'all_resumes' or any(k in msg_lower for k in ['all resume', 'strongest candidate', 'rank candidate', 'compare candidate', 'missing skill'])):
        resumes = Resume.query.order_by(Resume.created_at.desc()).limit(8).all()
        for res in resumes:
            if res.raw_text:
                context_docs.append({
                    'name': res.file_name or f"Resume_{res.candidate_name}",
                    'text': res.raw_text[:2500]
                })

    # Call Centralized Gemini Copilot
    result = ai_service.copilot_chat(
        message=message,
        context_docs=context_docs,
        user_info=user_info,
        chat_history=history
    )

    return jsonify({
        'reply': result.get('reply'),
        'engine': result.get('engine'),
        'model': result.get('model'),
        'sources': result.get('sources', []),
        'has_context': result.get('has_context', False),
        'user': user_info['name']
    })



