import os
from flask import Flask, render_template, jsonify, session
from config import Config
from models.models import db, User, Department, SubDepartment, HITLReview, Notification
from routes.auth import auth_bp
from routes.dashboard import dashboard_bp
from routes.invoices import invoices_bp
from routes.leads import leads_bp
from routes.resumes import resumes_bp
from routes.support import support_bp
from routes.hitl import hitl_bp
from routes.workflows import workflows_bp
from routes.analytics import analytics_bp
from routes.settings import settings_bp
from routes.api import api_bp
from routes.departments import departments_bp
from utils.helpers import get_current_user

def create_app(config_class=Config):
    app = Flask(__name__)
    app.config.from_object(config_class)

    # Initialize extensions
    db.init_app(app)

    # Register Blueprints
    app.register_blueprint(auth_bp)
    app.register_blueprint(dashboard_bp)
    app.register_blueprint(departments_bp)
    app.register_blueprint(invoices_bp)
    app.register_blueprint(leads_bp)
    app.register_blueprint(resumes_bp)
    app.register_blueprint(support_bp)
    app.register_blueprint(hitl_bp)
    app.register_blueprint(workflows_bp)
    app.register_blueprint(analytics_bp)
    app.register_blueprint(settings_bp)
    app.register_blueprint(api_bp)

    # Global Template Context
    @app.context_processor
    def inject_global_vars():
        current_u = get_current_user()
        try:
            pending_hitl_count = HITLReview.query.filter_by(action='Pending').count()
        except Exception:
            pending_hitl_count = 0
            
        try:
            unread_notifs_count = 0
            if current_u:
                role = (current_u.role or '').upper()
                if role == 'ADMIN':
                    unread_notifs_count = Notification.query.filter_by(is_read=False).count()
                else:
                    unread_notifs_count = Notification.query.filter(
                        Notification.is_read == False,
                        (Notification.role_target.in_(['ALL', role])) | (Notification.department_id == current_u.department_id)
                    ).count()
        except Exception:
            unread_notifs_count = 0

        try:
            all_depts = Department.query.all()
        except Exception:
            all_depts = []

        return dict(
            current_user=current_u,
            user_department=current_u.department_name if current_u else '',
            user_sub_department=current_u.sub_department_name if current_u else '',
            user_role=(current_u.role or '').upper() if current_u else '',
            pending_hitl_count=pending_hitl_count,
            unread_notifs_count=unread_notifs_count,
            all_departments=all_depts,
            min=min,
            max=max,
            round=round
        )


    # Custom Jinja Filters
    @app.template_filter('format_currency')
    def format_currency(value):
        try:
            return f"${float(value):,.2f}"
        except (ValueError, TypeError):
            return "$0.00"

    # Error Handlers
    @app.errorhandler(404)
    def not_found_error(error):
        return render_template('base.html'), 404

    @app.errorhandler(500)
    def internal_error(error):
        db.session.rollback()
        return jsonify({'error': 'Internal server error', 'message': 'An unexpected error occurred.'}), 500

    @app.errorhandler(413)
    def file_too_large(error):
        return jsonify({'error': 'File too large', 'message': 'Uploaded file exceeds the 16MB maximum size limit.'}), 413

    # Database Initialization & Auto-Seeding
    with app.app_context():
        db.create_all()
        # Seed initial demo data if database is fresh
        if User.query.count() == 0:
            from database.seed_data import seed_demo_database
            seed_demo_database()

    return app

app = create_app()

if __name__ == '__main__':
    port = int(os.getenv('PORT', 5000))
    debug = os.getenv('FLASK_DEBUG', '1') == '1'
    print(f"[SmartBiz] Starting Automation Server on http://127.0.0.1:{port}")
    app.run(host='0.0.0.0', port=port, debug=debug, threaded=True)
